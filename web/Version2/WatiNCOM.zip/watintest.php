<?php
$iface=new COM("WatiN.COMInterface") or die("Cannot create IE object");
$ie = $iface->CreateIE("http://www.google.com");
$ie->BringToFront();
$ie->TextField($iface->FindByName("q"))->TypeText("watin");
$ie->Button($iface->FindByName("btnG"))->Click();
$iface = null;
?>
