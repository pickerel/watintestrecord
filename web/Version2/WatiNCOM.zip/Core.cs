using System;
using System.Reflection;
using System.Collections.Generic;
using System.Text;
using WatiN.Core;
using System.ComponentModel;

namespace WatiN
{
    public class COMInterface
    {
        /// <summary>
        /// Creates a new internet explorer instance
        /// </summary>
        /// <param name="URL">URL to set the browser to</param>
        /// <returns>hash code of the IE instance</returns>
        public IECOM CreateIE(string URL)
        {
            IE ie = null;
            if (URL.Trim()=="")
            {
                ie = new IE();
            }
            else
            {
                ie = new IE(URL);
            }

            IECOM iecom = null;
            if (ie != null)
            {
                iecom = new IECOM(ie);
            }

            return iecom;
        }

        /// <summary>
        /// Checks whether an IE exists
        /// </summary>
        /// <param name="attribute">attribute to find the window</param>
        /// <returns>true when exists</returns>
        public bool Exists(AttributeCOM attribute)
        {
            return IE.Exists(attribute.watinattr);
        }

        /// <summary>
        /// List of IE windows
        /// </summary>
        public IECOM[] InternetExplorers
        {
            get
            {
                IECollection ielist = IE.InternetExplorers();
                IECOM[] _InternetExplorers = new IECOM[ielist.Length];
                for (int i = 0; i < ielist.Length; i++)
                {
                    _InternetExplorers[i] = new IECOM(ielist[i]);
                }
                return _InternetExplorers;
            }
        }

        /// <summary>
        /// Attach to an IECOM object based on window title
        /// </summary>
        /// <param name="Title">title to search for</param>
        /// <returns>IECOM object or null if nothing is found</returns>
        public IECOM AttachByTitle(string Title)
        {
            IE ie = IE.AttachToIE(Find.ByTitle(Title));
            IECOM iecom = null;
            if (ie != null)
            {
                iecom = new IECOM(ie);
            }
            return iecom;
        }

        /// <summary>
        /// Attach to an IECOM object based on URL
        /// </summary>
        /// <param name="Url">URL to search for</param>
        /// <returns>IECOM object or null if nothing is found</returns>
        public IECOM AttachByUrl(string Url)
        {
            IE ie = IE.AttachToIE(Find.ByUrl(Url));
            IECOM iecom = null;
            if (ie != null)
            {
                iecom = new IECOM(ie);
            }
            return iecom;
        }

        /// <summary>
        /// Find an element using a custom property
        /// </summary>
        /// <param name="AttributeName">Name of the element property</param>
        /// <param name="AttributeValue">Value of the property</param>
        /// <returns>attribute object used to find the element</returns>
        public AttributeCOM FindByCustom(string AttributeName, string AttributeValue)
        {
            WatiN.Core.Attribute attr = Find.ByCustom(AttributeName, AttributeValue);
            AttributeCOM acom = null;
            if (attr != null)
            {
                acom = new AttributeCOM(attr);
            }
            return acom;
        }

        /// <summary>
        /// Find an element using the Id
        /// </summary>
        /// <param name="Id">Id to search for</param>
        /// <returns>attribute object used to find the element</returns>
        public AttributeCOM FindById(string Id)
        {
            WatiN.Core.Attribute attr = Find.ById(Id);
            AttributeCOM acom = null;
            if (attr != null)
            {
                acom = new AttributeCOM(attr);
            }
            return acom;
        }

        /// <summary>
        /// Find an element by index
        /// </summary>
        /// <param name="Index">Index of the item to find</param>
        /// <returns>attribute object used to find the element</returns>
        public AttributeCOM FindByIndex(int Index)
        {
            WatiN.Core.Attribute attr = Find.ByIndex(Index);
            AttributeCOM acom = null;
            if (attr != null)
            {
                acom = new AttributeCOM(attr);
            }
            return acom;
        }

        /// <summary>
        /// Find an element by name
        /// </summary>
        /// <param name="Name">name to find</param>
        /// <returns>attribute object used to find the element</returns>
        public AttributeCOM FindByName(string Name)
        {
            WatiN.Core.Attribute attr = Find.ByName(Name);
            AttributeCOM acom = null;
            if (attr != null)
            {
                acom = new AttributeCOM(attr);
            }
            return acom;
        }

        /// <summary>
        /// Find an element by Src property 
        /// </summary>
        /// <param name="Src"></param>
        /// <returns>attribute object used to find the element</returns>
        public AttributeCOM FindBySrc(string Src)
        {
            WatiN.Core.Attribute attr = Find.BySrc(Src);
            AttributeCOM acom = null;
            if (attr != null)
            {
                acom = new AttributeCOM(attr);
            }
            return acom;
        }

        /// <summary>
        /// Find an element by style element 
        /// </summary>
        /// <param name="AttributeName">style attribute to find</param>
        /// <param name="AttributeValue">style value to find</param>
        /// <returns>attribute object used to find the element</returns>
        public AttributeCOM FindByStyle(string AttributeName, string AttributeValue)
        {
            WatiN.Core.Attribute attr = Find.ByStyle(AttributeName, AttributeValue);
            AttributeCOM acom = null;
            if (attr != null)
            {
                acom = new AttributeCOM(attr);
            }
            return acom;
        }

        /// <summary>
        /// Find an element by text value
        /// </summary>
        /// <param name="Text">text to find</param>
        /// <returns>attribute object used to find the element</returns>
        public AttributeCOM FindByText(string Text)
        {
            WatiN.Core.Attribute attr = Find.ByText(Text);
            AttributeCOM acom = null;
            if (attr != null)
            {
                acom = new AttributeCOM(attr);
            }
            return acom;
        }

        /// <summary>
        /// Find an element by URL property
        /// </summary>
        /// <param name="URL">property URL to find</param>
        /// <returns>attribute object used to find the element</returns>
        public AttributeCOM FindByUrl(string URL)
        {
            WatiN.Core.Attribute attr = Find.ByUrl(URL);
            AttributeCOM acom = null;
            if (attr != null)
            {
                acom = new AttributeCOM(attr);
            }
            return acom;
        }

        /// <summary>
        /// Find an element by value
        /// </summary>
        /// <param name="Value"></param>
        /// <returns>attribute object used to find the element</returns>
        public AttributeCOM FindByValue(string Value)
        {
            WatiN.Core.Attribute attr = Find.ByValue(Value);
            AttributeCOM acom = null;
            if (attr != null)
            {
                acom = new AttributeCOM(attr);
            }
            return acom;
        }

        /// <summary>
        /// Wait for a specific amount of time
        /// </summary>
        /// <param name="Ticks">miliseconds to wait</param>
        public void Wait(int Ticks)
        {
            System.Threading.Thread.Sleep(Ticks);
        }
    }

    public class AttributeCOM
    {
        public WatiN.Core.Attribute watinattr = null;
        public AttributeCOM(WatiN.Core.Attribute WatiNAttribute)
        {
            watinattr = WatiNAttribute;
        }
    }

    public class ElementsContainerCOM
    {
        WatiN.Core.ElementsContainer doc = null;
        public ElementsContainerCOM(WatiN.Core.ElementsContainer econ)
        {
            this.doc = econ;
        }

        public ButtonCOM Button(AttributeCOM attribute)
        {
            return new ButtonCOM(doc.Button(attribute.watinattr));
        }

        public ButtonCOM[] Buttons
        {
            get
            {
                ButtonCOM[] _buttons = new ButtonCOM[doc.Buttons.Length];
                for (int i = 0; i < doc.Buttons.Length; i++)
                {
                    _buttons[i] = new ButtonCOM(doc.Buttons[i]);
                }
                return _buttons;
            }
        }

        public DivCOM Div(AttributeCOM attribute)
        {
            return new DivCOM(doc.Div(attribute.watinattr));
        }

        public DivCOM[] Divs
        {
            get
            {
                DivCOM[] _divs = new DivCOM[doc.Divs.Length];
                for (int i = 0; i < doc.Divs.Length; i++)
                {
                    _divs[i] = new DivCOM(doc.Divs[i]);
                }
                return _divs;
            }
        }

        public ElementCOM Element(AttributeCOM attribute)
        {
            return new ElementCOM(doc.Element(attribute.watinattr));
        }

        public ElementCOM[] Elements
        {
            get
            {
                ElementCOM[] _elements = new ElementCOM[doc.Elements.Length];
                for (int i = 0; i < doc.Elements.Length; i++)
                {
                    _elements[i] = new ElementCOM(doc.Elements[i]);
                }
                return _elements;
            }
        }

        public CheckBoxCOM CheckBox(AttributeCOM attribute)
        {
            return new CheckBoxCOM(doc.CheckBox(attribute.watinattr));
        }

        public CheckBoxCOM[] CheckBoxes
        {
            get
            {
                CheckBoxCOM[] _chkbxs = new CheckBoxCOM[doc.CheckBoxes.Length];
                for (int i = 0; i < doc.CheckBoxes.Length; i++)
                {
                    _chkbxs[i] = new CheckBoxCOM(doc.CheckBoxes[i]);
                }
                return _chkbxs;
            }
        }

        public FileUploadCOM FileUpload(AttributeCOM attribute)
        {
            return new FileUploadCOM(doc.FileUpload(attribute.watinattr));
        }

        public FileUploadCOM[] FileUploads
        {
            get
            {
                FileUploadCOM[] _files = new FileUploadCOM[doc.FileUploads.Length];
                for (int i = 0; i < doc.FileUploads.Length; i++)
                {
                    _files[i] = new FileUploadCOM(doc.FileUploads[i]);
                }
                return _files;
            }
        }

        public FormCOM Form(AttributeCOM attribute)
        {
            return new FormCOM(doc.Form(attribute.watinattr));
        }

        public FormCOM[] Forms
        {
            get
            {
                FormCOM[] _Forms = new FormCOM[doc.Forms.Length];
                for (int i = 0; i < doc.Forms.Length; i++)
                {
                    _Forms[i] = new FormCOM(doc.Forms[i]);
                }
                return _Forms;
            }
        }

        public ImageCOM Image(AttributeCOM attribute)
        {
            return new ImageCOM(doc.Image(attribute.watinattr));
        }

        public ImageCOM[] Images
        {
            get
            {
                ImageCOM[] _Images = new ImageCOM[doc.Images.Length];
                for (int i = 0; i < doc.Images.Length; i++)
                {
                    _Images[i] = new ImageCOM(doc.Images[i]);
                }
                return _Images;
            }
        }

        public LabelCOM Label(AttributeCOM attribute)
        {
            return new LabelCOM(doc.Label(attribute.watinattr));
        }

        public LabelCOM[] Labels
        {
            get
            {
                LabelCOM[] _Labels = new LabelCOM[doc.Labels.Length];
                for (int i = 0; i < doc.Labels.Length; i++)
                {
                    _Labels[i] = new LabelCOM(doc.Labels[i]);
                }
                return _Labels;
            }
        }

        public LinkCOM Link(AttributeCOM attribute)
        {
            return new LinkCOM(doc.Link(attribute.watinattr));
        }

        public LinkCOM[] Links
        {
            get
            {
                LinkCOM[] _Links = new LinkCOM[doc.Links.Length];
                for (int i = 0; i < doc.Links.Length; i++)
                {
                    _Links[i] = new LinkCOM(doc.Links[i]);
                }
                return _Links;
            }
        }

        public ParaCOM Para(AttributeCOM attribute)
        {
            return new ParaCOM(doc.Para(attribute.watinattr));
        }

        public ParaCOM[] Paras
        {
            get
            {
                ParaCOM[] _Paras = new ParaCOM[doc.Paras.Length];
                for (int i = 0; i < doc.Paras.Length; i++)
                {
                    _Paras[i] = new ParaCOM(doc.Paras[i]);
                }
                return _Paras;
            }
        }

        public RadioButtonCOM RadioButton(AttributeCOM attribute)
        {
            return new RadioButtonCOM(doc.RadioButton(attribute.watinattr));
        }

        public RadioButtonCOM[] RadioButtons
        {
            get
            {
                RadioButtonCOM[] _RadioButtons = new RadioButtonCOM[doc.RadioButtons.Length];
                for (int i = 0; i < doc.RadioButtons.Length; i++)
                {
                    _RadioButtons[i] = new RadioButtonCOM(doc.RadioButtons[i]);
                }
                return _RadioButtons;
            }
        }

        public SelectListCOM SelectList(AttributeCOM attribute)
        {
            return new SelectListCOM(doc.SelectList(attribute.watinattr));
        }

        public SelectListCOM[] SelectLists
        {
            get
            {
                SelectListCOM[] _SelectLists = new SelectListCOM[doc.SelectLists.Length];
                for (int i = 0; i < doc.SelectLists.Length; i++)
                {
                    _SelectLists[i] = new SelectListCOM(doc.SelectLists[i]);
                }
                return _SelectLists;
            }
        }

        public SpanCOM Span(AttributeCOM attribute)
        {
            return new SpanCOM(doc.Span(attribute.watinattr));
        }

        public SpanCOM[] Spans
        {
            get
            {
                SpanCOM[] _Spans = new SpanCOM[doc.Spans.Length];
                for (int i = 0; i < doc.Spans.Length; i++)
                {
                    _Spans[i] = new SpanCOM(doc.Spans[i]);
                }
                return _Spans;
            }
        }

        public TextFieldCOM TextField(AttributeCOM attribute)
        {
            return new TextFieldCOM(doc.TextField(attribute.watinattr));
        }

        public TextFieldCOM[] TextFields
        {
            get
            {
                TextFieldCOM[] _TextFields = new TextFieldCOM[doc.TextFields.Length];
                for (int i = 0; i < doc.TextFields.Length; i++)
                {
                    _TextFields[i] = new TextFieldCOM(doc.TextFields[i]);
                }
                return _TextFields;
            }
        }

        public TableCOM Table(AttributeCOM attribute)
        {
            return new TableCOM(doc.Table(attribute.watinattr));
        }

        public TableCOM[] Tables
        {
            get
            {
                TableCOM[] _Tables = new TableCOM[doc.Tables.Length];
                for (int i = 0; i < doc.Tables.Length; i++)
                {
                    _Tables[i] = new TableCOM(doc.Tables[i]);
                }
                return _Tables;
            }
        }

        public TableBodyCOM TableBody(AttributeCOM attribute)
        {
            return new TableBodyCOM(doc.TableBody(attribute.watinattr));
        }

        public TableBodyCOM[] TableBodies
        {
            get
            {
                TableBodyCOM[] _TableBodies = new TableBodyCOM[doc.TableBodies.Length];
                for (int i = 0; i < doc.TableBodies.Length; i++)
                {
                    _TableBodies[i] = new TableBodyCOM(doc.TableBodies[i]);
                }
                return _TableBodies;
            }
        }

        public TableCellCOM TableCell(AttributeCOM attribute)
        {
            return new TableCellCOM(doc.TableCell(attribute.watinattr));
        }

        public TableCellCOM[] TableCells
        {
            get
            {
                TableCellCOM[] _TableCells = new TableCellCOM[doc.TableCells.Length];
                for (int i = 0; i < doc.TableCells.Length; i++)
                {
                    _TableCells[i] = new TableCellCOM(doc.TableCells[i]);
                }
                return _TableCells;
            }
        }

        public TableRowCOM TableRow(AttributeCOM attribute)
        {
            return new TableRowCOM(doc.TableRow(attribute.watinattr));
        }

        public TableRowCOM[] TableRows
        {
            get
            {
                TableRowCOM[] _TableRows = new TableRowCOM[doc.TableRows.Length];
                for (int i = 0; i < doc.TableRows.Length; i++)
                {
                    _TableRows[i] = new TableRowCOM(doc.TableRows[i]);
                }
                return _TableRows;
            }
        }
    }

    public class DocumentCOM
    {
        WatiN.Core.Document doc = null;
        public DocumentCOM(WatiN.Core.Document doc)
        {
            this.doc = doc;
        }

        public bool ContainsText(string TextToFind)
        {
            return doc.ContainsText(TextToFind);
        }

        public string Html
        {
            get
            {
                return doc.Html;
            }
        }

        public string Title
        {
            get
            {
                return doc.Title;
            }
        }

        public void RunScript(string ScriptCode, string Language)
        {
            doc.RunScript(ScriptCode, Language);
        }

        public string Url
        {
            get
            {
                return doc.Url;
            }
        }

        public ButtonCOM Button(AttributeCOM attribute)
        {
            return new ButtonCOM(doc.Button(attribute.watinattr));
        }

        public ButtonCOM[] Buttons
        {
            get
            {
                ButtonCOM[] _buttons = new ButtonCOM[doc.Buttons.Length];
                for (int i = 0; i < doc.Buttons.Length; i++)
                {
                    _buttons[i] = new ButtonCOM(doc.Buttons[i]);
                }
                return _buttons;
            }
        }

        public DivCOM Div(AttributeCOM attribute)
        {
            return new DivCOM(doc.Div(attribute.watinattr));
        }

        public DivCOM[] Divs
        {
            get
            {
                DivCOM[] _divs = new DivCOM[doc.Divs.Length];
                for (int i = 0; i < doc.Divs.Length; i++)
                {
                    _divs[i] = new DivCOM(doc.Divs[i]);
                }
                return _divs;
            }
        }

        public ElementCOM Element(AttributeCOM attribute)
        {
            return new ElementCOM(doc.Element(attribute.watinattr));
        }

        public ElementCOM[] Elements
        {
            get
            {
                ElementCOM[] _elements = new ElementCOM[doc.Elements.Length];
                for (int i = 0; i < doc.Elements.Length; i++)
                {
                    _elements[i] = new ElementCOM(doc.Elements[i]);
                }
                return _elements;
            }
        }

        public CheckBoxCOM CheckBox(AttributeCOM attribute)
        {
            return new CheckBoxCOM(doc.CheckBox(attribute.watinattr));
        }

        public CheckBoxCOM[] CheckBoxes
        {
            get
            {
                CheckBoxCOM[] _chkbxs = new CheckBoxCOM[doc.CheckBoxes.Length];
                for (int i = 0; i < doc.CheckBoxes.Length; i++)
                {
                    _chkbxs[i] = new CheckBoxCOM(doc.CheckBoxes[i]);
                }
                return _chkbxs;
            }
        }

        public FileUploadCOM FileUpload(AttributeCOM attribute)
        {
            return new FileUploadCOM(doc.FileUpload(attribute.watinattr));
        }

        public FileUploadCOM[] FileUploads
        {
            get
            {
                FileUploadCOM[] _files = new FileUploadCOM[doc.FileUploads.Length];
                for (int i = 0; i < doc.FileUploads.Length; i++)
                {
                    _files[i] = new FileUploadCOM(doc.FileUploads[i]);
                }
                return _files;
            }
        }

        public FormCOM Form(AttributeCOM attribute)
        {
            return new FormCOM(doc.Form(attribute.watinattr));
        }

        public FormCOM[] Forms
        {
            get
            {
                FormCOM[] _Forms = new FormCOM[doc.Forms.Length];
                for (int i = 0; i < doc.Forms.Length; i++)
                {
                    _Forms[i] = new FormCOM(doc.Forms[i]);
                }
                return _Forms;
            }
        }

        public ImageCOM Image(AttributeCOM attribute)
        {
            return new ImageCOM(doc.Image(attribute.watinattr));
        }

        public ImageCOM[] Images
        {
            get
            {
                ImageCOM[] _Images = new ImageCOM[doc.Images.Length];
                for (int i = 0; i < doc.Images.Length; i++)
                {
                    _Images[i] = new ImageCOM(doc.Images[i]);
                }
                return _Images;
            }
        }

        public LabelCOM Label(AttributeCOM attribute)
        {
            return new LabelCOM(doc.Label(attribute.watinattr));
        }

        public LabelCOM[] Labels
        {
            get
            {
                LabelCOM[] _Labels = new LabelCOM[doc.Labels.Length];
                for (int i = 0; i < doc.Labels.Length; i++)
                {
                    _Labels[i] = new LabelCOM(doc.Labels[i]);
                }
                return _Labels;
            }
        }

        public LinkCOM Link(AttributeCOM attribute)
        {
            return new LinkCOM(doc.Link(attribute.watinattr));
        }

        public LinkCOM[] Links
        {
            get
            {
                LinkCOM[] _Links = new LinkCOM[doc.Links.Length];
                for (int i = 0; i < doc.Links.Length; i++)
                {
                    _Links[i] = new LinkCOM(doc.Links[i]);
                }
                return _Links;
            }
        }

        public ParaCOM Para(AttributeCOM attribute)
        {
            return new ParaCOM(doc.Para(attribute.watinattr));
        }

        public ParaCOM[] Paras
        {
            get
            {
                ParaCOM[] _Paras = new ParaCOM[doc.Paras.Length];
                for (int i = 0; i < doc.Paras.Length; i++)
                {
                    _Paras[i] = new ParaCOM(doc.Paras[i]);
                }
                return _Paras;
            }
        }

        public RadioButtonCOM RadioButton(AttributeCOM attribute)
        {
            return new RadioButtonCOM(doc.RadioButton(attribute.watinattr));
        }

        public RadioButtonCOM[] RadioButtons
        {
            get
            {
                RadioButtonCOM[] _RadioButtons = new RadioButtonCOM[doc.RadioButtons.Length];
                for (int i = 0; i < doc.RadioButtons.Length; i++)
                {
                    _RadioButtons[i] = new RadioButtonCOM(doc.RadioButtons[i]);
                }
                return _RadioButtons;
            }
        }

        public SelectListCOM SelectList(AttributeCOM attribute)
        {
            return new SelectListCOM(doc.SelectList(attribute.watinattr));
        }

        public SelectListCOM[] SelectLists
        {
            get
            {
                SelectListCOM[] _SelectLists = new SelectListCOM[doc.SelectLists.Length];
                for (int i = 0; i < doc.SelectLists.Length; i++)
                {
                    _SelectLists[i] = new SelectListCOM(doc.SelectLists[i]);
                }
                return _SelectLists;
            }
        }

        public SpanCOM Span(AttributeCOM attribute)
        {
            return new SpanCOM(doc.Span(attribute.watinattr));
        }

        public SpanCOM[] Spans
        {
            get
            {
                SpanCOM[] _Spans = new SpanCOM[doc.Spans.Length];
                for (int i = 0; i < doc.Spans.Length; i++)
                {
                    _Spans[i] = new SpanCOM(doc.Spans[i]);
                }
                return _Spans;
            }
        }

        public TextFieldCOM TextField(AttributeCOM attribute)
        {
            return new TextFieldCOM(doc.TextField(attribute.watinattr));
        }

        public TextFieldCOM[] TextFields
        {
            get
            {
                TextFieldCOM[] _TextFields = new TextFieldCOM[doc.TextFields.Length];
                for (int i = 0; i < doc.TextFields.Length; i++)
                {
                    _TextFields[i] = new TextFieldCOM(doc.TextFields[i]);
                }
                return _TextFields;
            }
        }

        public TableCOM Table(AttributeCOM attribute)
        {
            return new TableCOM(doc.Table(attribute.watinattr));
        }

        public TableCOM[] Tables
        {
            get
            {
                TableCOM[] _Tables = new TableCOM[doc.Tables.Length];
                for (int i = 0; i < doc.Tables.Length; i++)
                {
                    _Tables[i] = new TableCOM(doc.Tables[i]);
                }
                return _Tables;
            }
        }

        public TableBodyCOM TableBody(AttributeCOM attribute)
        {
            return new TableBodyCOM(doc.TableBody(attribute.watinattr));
        }

        public TableBodyCOM[] TableBodies
        {
            get
            {
                TableBodyCOM[] _TableBodies = new TableBodyCOM[doc.TableBodies.Length];
                for (int i = 0; i < doc.TableBodies.Length; i++)
                {
                    _TableBodies[i] = new TableBodyCOM(doc.TableBodies[i]);
                }
                return _TableBodies;
            }
        }

        public TableCellCOM TableCell(AttributeCOM attribute)
        {
            return new TableCellCOM(doc.TableCell(attribute.watinattr));
        }

        public TableCellCOM[] TableCells
        {
            get
            {
                TableCellCOM[] _TableCells = new TableCellCOM[doc.TableCells.Length];
                for (int i = 0; i < doc.TableCells.Length; i++)
                {
                    _TableCells[i] = new TableCellCOM(doc.TableCells[i]);
                }
                return _TableCells;
            }
        }

        public TableRowCOM TableRow(AttributeCOM attribute)
        {
            return new TableRowCOM(doc.TableRow(attribute.watinattr));
        }

        public TableRowCOM[] TableRows
        {
            get
            {
                TableRowCOM[] _TableRows = new TableRowCOM[doc.TableRows.Length];
                for (int i = 0; i < doc.TableRows.Length; i++)
                {
                    _TableRows[i] = new TableRowCOM(doc.TableRows[i]);
                }
                return _TableRows;
            }
        }
    }

    public class DomContainerCOM : DocumentCOM
    {
        WatiN.Core.DomContainer dom = null;
        public DomContainerCOM(WatiN.Core.DomContainer dom)
            : base(dom)
        {
            this.dom = dom;
        }

        public int hWnd
        {
            get
            {
                return (int)dom.hWnd;
            }
        }

        public int ProcessID
        {
            get
            {
                return dom.ProcessID;
            }
        }

        public void WaitForComplete()
        {
            dom.WaitForComplete();
        }

        public void AddHandlerLogin(string Username, string Password)
        {
            dom.AddDialogHandler(new WatiN.Core.DialogHandlers.LogonDialogHandler(Username, Password));
        }

        public void AddHandlerCertificateWarning(bool ClickYes)
        {
            if (ClickYes)
            {
                dom.AddDialogHandler(new WatiN.Core.DialogHandlers.CertificateWarningHandler(WatiN.Core.DialogHandlers.CertificateWarningHandler.ButtonsEnum.Yes));
            }
            else
            {
                dom.AddDialogHandler(new WatiN.Core.DialogHandlers.CertificateWarningHandler(WatiN.Core.DialogHandlers.CertificateWarningHandler.ButtonsEnum.No));
            }
        }

        public DialogHandlersCOM.AlertDialogHandlerCOM AddHandlerAlertDialog()
        {
            WatiN.Core.DialogHandlers.AlertDialogHandler acdlg = new WatiN.Core.DialogHandlers.AlertDialogHandler();
            DialogHandlersCOM.AlertDialogHandlerCOM acdlgcom = new DialogHandlersCOM.AlertDialogHandlerCOM(acdlg);
            dom.AddDialogHandler(acdlg);
            return acdlgcom;
        }

        public DialogHandlersCOM.ConfirmDialogHandlerCOM AddHandlerConfirmDialog()
        {
            WatiN.Core.DialogHandlers.ConfirmDialogHandler cdlg = new WatiN.Core.DialogHandlers.ConfirmDialogHandler();
            DialogHandlersCOM.ConfirmDialogHandlerCOM cdlgcom = new DialogHandlersCOM.ConfirmDialogHandlerCOM(cdlg);
            dom.AddDialogHandler(cdlg);
            return cdlgcom;
        }

        public DialogHandlersCOM.FileDownloadHandlerCOM AddHandlerFileSave(string Filename)
        {
            WatiN.Core.DialogHandlers.FileDownloadHandler file = new WatiN.Core.DialogHandlers.FileDownloadHandler(Filename);
            DialogHandlersCOM.FileDownloadHandlerCOM filecom = new DialogHandlersCOM.FileDownloadHandlerCOM(file);
            dom.AddDialogHandler(file);
            return filecom;
        }

        public DialogHandlersCOM.FileDownloadHandlerCOM AddHandlerFileRun()
        {
            WatiN.Core.DialogHandlers.FileDownloadHandler file = new WatiN.Core.DialogHandlers.FileDownloadHandler(WatiN.Core.DialogHandlers.FileDownloadOption.Run);
            DialogHandlersCOM.FileDownloadHandlerCOM filecom = new DialogHandlersCOM.FileDownloadHandlerCOM(file);
            dom.AddDialogHandler(file);
            return filecom;
        }

        public DialogHandlersCOM.FileDownloadHandlerCOM AddHandlerFileOpen()
        {
            WatiN.Core.DialogHandlers.FileDownloadHandler file = new WatiN.Core.DialogHandlers.FileDownloadHandler(WatiN.Core.DialogHandlers.FileDownloadOption.Open);
            DialogHandlersCOM.FileDownloadHandlerCOM filecom = new DialogHandlersCOM.FileDownloadHandlerCOM(file);
            dom.AddDialogHandler(file);
            return filecom;
        }

        public DialogHandlersCOM.FileDownloadHandlerCOM AddHandlerFileCancel()
        {
            WatiN.Core.DialogHandlers.FileDownloadHandler file = new WatiN.Core.DialogHandlers.FileDownloadHandler(WatiN.Core.DialogHandlers.FileDownloadOption.Cancel);
            DialogHandlersCOM.FileDownloadHandlerCOM filecom = new DialogHandlersCOM.FileDownloadHandlerCOM(file);
            dom.AddDialogHandler(file);
            return filecom;
        }

        public void AddHandlerSecurityAlertDialog()
        {
            dom.AddDialogHandler(new WatiN.Core.DialogHandlers.SecurityAlertDialogHandler());
        }
    }

    public class DialogHandlersCOM
    {
        public class AlertDialogHandlerCOM
        {
            WatiN.Core.DialogHandlers.AlertDialogHandler adlg = null;
            public AlertDialogHandlerCOM(WatiN.Core.DialogHandlers.AlertDialogHandler adlg)
            {
                this.adlg = adlg;
            }

            public string Message
            {
                get
                {
                    return adlg.Message;
                }
            }

            public string Title
            {
                get
                {
                    return adlg.Title;
                }
            }

            public void ClickOK()
            {
                adlg.OKButton.Click();
            }

            public void WaitUntilExists(int WaitDuration)
            {
                adlg.WaitUntilExists(WaitDuration);
            }
        }

        public class ConfirmDialogHandlerCOM
        {
            WatiN.Core.DialogHandlers.ConfirmDialogHandler cdlg = null;
            public ConfirmDialogHandlerCOM(WatiN.Core.DialogHandlers.ConfirmDialogHandler cdlg)
            {
                this.cdlg = cdlg;
            }

            public string Message
            {
                get
                {
                    return cdlg.Message;
                }
            }

            public string Title
            {
                get
                {
                    return cdlg.Title;
                }
            }

            public void ClickOK()
            {
                cdlg.OKButton.Click();
            }

            public void ClickCancel()
            {
                cdlg.CancelButton.Click();
            }

            public void WaitUntilExists(int WaitDuration)
            {
                cdlg.WaitUntilExists(WaitDuration);
            }
        }

        public class FileDownloadHandlerCOM
        {
            WatiN.Core.DialogHandlers.FileDownloadHandler file = null;
            public FileDownloadHandlerCOM(WatiN.Core.DialogHandlers.FileDownloadHandler file)
            {
                this.file = file;
            }

            public string SaveAsFilename
            {
                get
                {
                    return file.SaveAsFilename;
                }
            }

            public void WaitUntilDownloadCompleted(int waitDurationInSeconds)
            {
                file.WaitUntilDownloadCompleted(waitDurationInSeconds);
            }

            public void WaitUntilFileDownloadDialogIsHandled(int waitDurationInSeconds)
            {
                file.WaitUntilFileDownloadDialogIsHandled(waitDurationInSeconds);
            }
        }
    }

    public class IECOM : DomContainerCOM
    {
        IE ie = null;
        public IECOM(IE ie) : base(ie)
        {
            this.ie = ie;
        }

        public void Back()
        {
            ie.Back();
        }

        public void GoTo(string URL)
        {
            ie.GoTo(URL);
        }

        public void BringToFront()
        {
            ie.BringToFront();
        }

        public void ForceClose()
        {
            ie.ForceClose();
        }

        public void Forward()
        {
            ie.Forward();
        }

        public HtmlDialogCOM HtmlDialog(AttributeCOM attribute)
        {
            return new HtmlDialogCOM(ie.HtmlDialog(attribute.watinattr));
        }

        public HtmlDialogCOM[] HtmlDialogs
        {
            get
            {
                HtmlDialogCOM[] _HtmlDialogs = new HtmlDialogCOM[ie.HtmlDialogs.Length];
                for (int i = 0; i < ie.HtmlDialogs.Length; i++)
                {
                    _HtmlDialogs[i] = new HtmlDialogCOM(ie.HtmlDialogs[i]);
                }
                return _HtmlDialogs;
            }
        }

        public void PressTab()
        {
            ie.PressTab();
        }

        public void Refresh()
        {
            ie.Refresh();
        }
    }

    public class ElementCOM
    {
        WatiN.Core.Element watinelement = null;

        public ElementCOM(WatiN.Core.Element element)
        {
            watinelement = element;
        }

        public void Blur()
        {
            watinelement.Blur();
        }

        public void Change()
        {
            watinelement.Change();
        }

        public string ClassName
        {
            get
            {
                return watinelement.ClassName;
            }
        }

        public void Click()
        {
            watinelement.Click();
        }

        public void ClickNoWait()
        {
            watinelement.ClickNoWait();
        }

        public bool Complete
        {
            get
            {
                return watinelement.Complete;
            }
        }

        public void DoubleClick()
        {
            watinelement.DoubleClick();
        }

        public bool Enabled
        {
            get
            {
                return watinelement.Enabled;
            }
        }

        public bool Exists
        {
            get
            {
                return watinelement.Exists;
            }
        }

        public void FireEvent(string EventName)
        {
            watinelement.FireEvent(EventName);
        }

        public void FireEventNoWait(string EventName)
        {
            watinelement.FireEvent(EventName);
        }

        public void Flash(int Count)
        {
            watinelement.Flash(Count);
        }

        public void Focus()
        {
            watinelement.Focus();
        }

        public string GetAttributeValue(string AttributeName)
        {
            return watinelement.GetAttributeValue(AttributeName);
        }

        public object HtmlElement
        {
            get
            {
                return watinelement.HTMLElement;
            }
        }

        public string Id
        {
            get
            {
                return watinelement.Id;
            }
        }

        public string InnerHtml
        {
            get
            {
                return watinelement.InnerHtml;
            }
        }

        public void KeyDown()
        {
            watinelement.KeyDown();
        }

        public void KeyPress()
        {
            watinelement.KeyPress();
        }

        public void KeyUp()
        {
            watinelement.KeyUp();
        }

        public void MouseDown()
        {
            watinelement.MouseDown();
        }

        public void MouseEnter()
        {
            watinelement.MouseEnter();
        }

        public void MouseUp()
        {
            watinelement.MouseUp();
        }

        public ElementCOM NextSibling
        {
            get
            {
                return new ElementCOM(watinelement.NextSibling);
            }
        }

        public string OuterHtml
        {
            get
            {
                return watinelement.OuterHtml;
            }
        }

        public string OuterText
        {
            get
            {
                return watinelement.OuterText;
            }
        }

        public ElementCOM Parent
        {
            get
            {
                return new ElementCOM(watinelement.Parent);
            }
        }

        public ElementCOM PreviousSibling
        {
            get
            {
                return new ElementCOM(watinelement.PreviousSibling);
            }
        }

        public void Refresh()
        {
            watinelement.Refresh();
        }

        public string TagName
        {
            get
            {
                return watinelement.TagName;
            }
        }

        public string Text
        {
            get
            {
                return watinelement.Text;
            }
        }

        public string TextAfter
        {
            get
            {
                return watinelement.TextAfter;
            }
        }

        public string TextBefore
        {
            get
            {
                return watinelement.TextBefore;
            }
        }

        public string Title
        {
            get
            {
                return watinelement.Title;
            }
        }

        public void WaitForComplete()
        {
            watinelement.WaitForComplete();
        }

        public void WaitUntil(string AttributeName, string ExpectedValue, int Timeout)
        {
            watinelement.WaitUntil(AttributeName, ExpectedValue, Timeout);
        }

        public void WaitUntilExists(int Timeout)
        {
            watinelement.WaitUntilExists(Timeout);
        }

        public void WaitUntilRemoved(int Timeout)
        {
            watinelement.WaitUntilRemoved(Timeout);
        }
    }

    public class ButtonCOM : ElementCOM
    {
        WatiN.Core.Button btn = null;

        public ButtonCOM(WatiN.Core.Button btn) : base(btn) 
        {
            this.btn = btn;
        }

        public string Value
        {
            get
            {
                return btn.Value;
            }
        }
    }

    public class DivCOM : ElementsContainerCOM
    {
        public DivCOM(WatiN.Core.Div divelement) : base(divelement) { }
    }

    public class RadioCheckCOM : ElementCOM
    {
        WatiN.Core.RadioCheck chkbx = null;

        public RadioCheckCOM(WatiN.Core.RadioCheck chk)
            : base(chk)
        {
            this.chkbx = chk;
        }

        public bool Checked
        {
            get
            {
                return chkbx.Checked;
            }
            set
            {
                chkbx.Checked = value;

            }
        }
    }

    public class CheckBoxCOM : RadioCheckCOM
    {
        public CheckBoxCOM(WatiN.Core.CheckBox chk) : base(chk) { }
    }

    public class FileUploadCOM : ElementCOM
    {
        WatiN.Core.FileUpload uploader = null;

        public FileUploadCOM(WatiN.Core.FileUpload upld) : base(upld)
        {
            this.uploader = upld;
        }

        public void Set(string Filename)
        {
            uploader.Set(Filename);
        }

        public string Filename
        {
            get
            {
                return uploader.FileName;
            }
        }
    }

    public class FormCOM : ElementsContainerCOM
    {
        WatiN.Core.Form frm = null;

        public FormCOM(WatiN.Core.Form frm) : base(frm)
        {
            this.frm = frm;
        }

        public string Name
        {
            get
            {
                return this.frm.Name;
            }
        }

        public void Submit()
        {
            this.frm.Submit();
        }
    }

    public class FrameCOM : DocumentCOM
    {
        WatiN.Core.Frame frame = null;

        public FrameCOM(WatiN.Core.Frame frame)
            : base(frame)
        {
            this.frame = frame;
        }

        public string Name
        {
            get
            {
                return this.frame.Name;
            }
        }

        public string Id
        {
            get
            {
                return this.frame.Id;
            }
        }
    }

    public class HtmlDialogCOM : DocumentCOM
    {
        WatiN.Core.HtmlDialog dlg = null;

        public HtmlDialogCOM(WatiN.Core.HtmlDialog dlg) : base(dlg)
        {
            this.dlg = dlg;
        }

        public void Close()
        {
            dlg.Close();
        }
    }

    public class ImageCOM : ElementCOM
    {
        WatiN.Core.Image wimg = null;

        public ImageCOM(WatiN.Core.Image img) : base(img)
        {
            wimg = img;
        }

        public string Src
        {
            get
            {
                return wimg.Src;
            }
        }

        public string Alt
        {
            get
            {
                return wimg.Alt;
            }
        }

        public string Name
        {
            get
            {
                return wimg.Name;
            }
        }
    }

    public class LabelCOM : ElementCOM
    {
        public LabelCOM(WatiN.Core.Label lbl) : base(lbl) { }
    }

    public class LinkCOM : ElementCOM
    {
        WatiN.Core.Link lnk = null;
        public LinkCOM(WatiN.Core.Link link) : base(link)
        {
            lnk = link;
        }

        public string Url
        {
            get
            {
                return lnk.Url;
            }
        }
    }

    public class OptionCOM : ElementCOM
    {
        WatiN.Core.Option op = null;
        public OptionCOM(WatiN.Core.Option opt) : base(opt)
        {
            op = opt;
        }

        public string Value
        {
            get
            {
                return op.Value;
            }
        }

        public int Index
        {
            get
            {
                return op.Index;
            }
        }

        public bool Selected
        {
            get
            {
                return op.Selected;
            }
        }

        public bool DefaultSelected
        {
            get
            {
                return op.DefaultSelected;
            }
        }

        public void Clear()
        {
            op.Clear();
        }

        public void ClearNoWait()
        {
            op.ClearNoWait();
        }

        public void Select()
        {
            op.Select();
        }

        public void SelectNoWait()
        {
            op.SelectNoWait();
        }

        public SelectListCOM ParentSelectList
        {
            get
            {
                return new SelectListCOM(op.ParentSelectList);
            }
        }
    }

    public class ParaCOM : ElementCOM
    {
        public ParaCOM(WatiN.Core.Para p) : base(p) { }
    }

    public class RadioButtonCOM : RadioCheckCOM
    {
        public RadioButtonCOM(WatiN.Core.RadioButton rbtn) : base(rbtn) { }
    }

    public class SelectListCOM : ElementCOM
    {
        WatiN.Core.SelectList sellist = null;

        public SelectListCOM(WatiN.Core.SelectList sel) : base(sel)
        {
            this.sellist = sel;
        }

        public void Select(string TextName)
        {
            sellist.Select(TextName);
        }

        public void SelectByValue(string TextValue)
        {
            sellist.SelectByValue(TextValue);
        }

        public void ClearList()
        {
            sellist.ClearList();
        }

        public OptionCOM Option(string text)
        {
            return new OptionCOM(sellist.Option(text));
        }

        public bool HasSelectedItems
        {
            get
            {
                return sellist.HasSelectedItems;
            }
        }

        public bool Multiple
        {
            get
            {
                return sellist.Multiple;
            }
        }

        public string SelectedItem
        {
            get
            {
                return sellist.SelectedItem;
            }
            set
            {
                sellist.Select(value);
            }
        }

        public OptionCOM SelectedOption
        {
            get
            {
                return new OptionCOM(sellist.SelectedOption);
            }
        }

        public string[] AllContents
        {
            get
            {
                string[] contents = new string[sellist.AllContents.Count];
                for (int i = 0; i < sellist.AllContents.Count; i++)
                {
                    contents[i] = sellist.AllContents[i];
                }
                return contents;
            }
        }

        public string[] SelectedItems
        {
            get
            {
                string[] items = new string[sellist.SelectedItems.Count];
                for (int i = 0; i < sellist.SelectedItems.Count; i++)
                {
                    items[i] = sellist.SelectedItems[i];
                }
                return items;
            }
        }

        public OptionCOM[] SelectedOptions
        {
            get
            {
                OptionCOM[] items = new OptionCOM[sellist.SelectedOptions.Count];
                for (int i = 0; i < sellist.SelectedOptions.Count; i++)
                {
                    items[i] = new OptionCOM(sellist.SelectedOptions[i] as Option);
                }
                return items;
            }
        }
    }

    public class SpanCOM : ElementsContainerCOM
    {
        public SpanCOM(WatiN.Core.Span spn) : base(spn) { }
    }

    public class TableCOM : ElementsContainerCOM
    {
        WatiN.Core.Table table = null;
        public TableCOM(WatiN.Core.Table tbl) : base(tbl)
        {
            table = tbl;
        }

        public TableRowCOM FindRow(string findText, int inColumn)
        {
            return new TableRowCOM(table.FindRow(findText, inColumn));
        }
    }

    public class TableBodyCOM : ElementsContainerCOM
    {
        public TableBodyCOM(WatiN.Core.TableBody tbody) : base(tbody) { }
    }

    public class TableCellCOM : ElementsContainerCOM
    {
        WatiN.Core.TableCell cell = null;

        public TableCellCOM(WatiN.Core.TableCell tcell) : base(tcell)
        {
            cell = tcell;
        }

        public TableRowCOM ParentTableRow
        {
            get
            {
                return new TableRowCOM(cell.ParentTableRow);
            }
        }
    }

    public class TableRowCOM : ElementsContainerCOM
    {
        WatiN.Core.TableRow row = null;
        public TableRowCOM(WatiN.Core.TableRow trow) : base(trow)
        {
            row = trow;
        }

        public TableCOM ParentTable
        {
            get
            {
                return new TableCOM(row.ParentTable);
            }
        }
    }

    public class TextFieldCOM : ElementCOM
    {
        WatiN.Core.TextField txtfield = null;

        public TextFieldCOM(WatiN.Core.TextField txt)
            : base(txt)
        {
            this.txtfield = txt;
        }

        public void TypeText(string TextToType)
        {
            txtfield.TypeText(TextToType);
        }

        public int MaxLength
        {
            get
            {
                return txtfield.MaxLength;
            }
        }

        public bool ReadOnly
        {
            get
            {
                return txtfield.ReadOnly;
            }
        }

        public string Value
        {
            get
            {
                return txtfield.Value;
            }
        }

        public void Select()
        {
            txtfield.Select();
        }


        public string Name
        {
            get
            {
                return txtfield.Name;
            }
        }

        public void AppendText(string Text)
        {
            txtfield.AppendText(Text);
        }

        public void Clear()
        {
            txtfield.Clear();
        }
    }
}
