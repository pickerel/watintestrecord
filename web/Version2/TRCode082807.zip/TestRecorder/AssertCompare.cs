//using System;
using System.Collections.Generic;
using System.Text;

namespace WatiN.Tests
{
    public class Notification
    {
        public static void Pass(string Message)
        {
            StreamWriter writer = new StreamWriter("PassingTest.txt");
            writer.WriteLine(Message);
            writer.Close();
        }

        public static void Fail(string Message)
        {
            StreamWriter writer = new StreamWriter("FailingTest.txt");
            writer.WriteLine(Message);
            writer.Close();
        }
    }

    public class Assert
    {
        public static void AreEqual(string intended, string actual, string message)
        {
            if (intended.Equals(actual))
            {
                Notification.Pass(message);
            }
            else
            {
                Notification.Fail(message);
            }
        }
        public static void AreEqual(int intended, int actual, string message)
        {
            if (intended.Equals(actual))
            {
                Notification.Pass(message);
            }
            else
            {
                Notification.Fail(message);
            }
        }
        public static void AreEqual(decimal intended, decimal actual, string message)
        {
            if (intended.Equals(actual))
            {
                Notification.Pass(message);
            }
            else
            {
                Notification.Fail(message);
            }
        }
        public static void AreNotEqual(string intended, string actual, string message)
        {
            if (!intended.Equals(actual))
            {
                Notification.Pass(message);
            }
            else
            {
                Notification.Fail(message);
            }
        }
        public static void AreNotEqual(int intended, int actual, string message)
        {
            if (!intended.Equals(actual))
            {
                Notification.Pass(message);
            }
            else
            {
                Notification.Fail(message);
            }
        }
        public static void AreNotEqual(decimal intended, decimal actual, string message)
        {
            if (!intended.Equals(actual))
            {
                Notification.Pass(message);
            }
            else
            {
                Notification.Fail(message);
            }
        }
        public static void Greater(int intended, int actual, string message)
        {
            if (intended < actual)
            {
                Notification.Pass(message);
            }
            else
            {
                Notification.Fail(message);
            }
        }
        public static void Greater(decimal intended, decimal actual, string message)
        {
            if (intended < actual)
            {
                Notification.Pass(message);
            }
            else
            {
                Notification.Fail(message);
            }
        }
        public static void GreaterOrEqual(int intended, int actual, string message)
        {
            if (intended <= actual)
            {
                Notification.Pass(message);
            }
            else
            {
                Notification.Fail(message);
            }
        }
        public static void GreaterOrEqual(decimal intended, decimal actual, string message)
        {
            if (intended <= actual)
            {
                Notification.Pass(message);
            }
            else
            {
                Notification.Fail(message);
            }
        }
        public static void Less(int intended, int actual, string message)
        {
            if (intended > actual)
            {
                Notification.Pass(message);
            }
            else
            {
                Notification.Fail(message);
            }
        }
        public static void Less(decimal intended, decimal actual, string message)
        {
            if (intended > actual)
            {
                Notification.Pass(message);
            }
            else
            {
                Notification.Fail(message);
            }
        }
        public static void LessOrEqual(int intended, int actual, string message)
        {
            if (intended >= actual)
            {
                Notification.Pass(message);
            }
            else
            {
                Notification.Fail(message);
            }
        }
        public static void LessOrEqual(decimal intended, decimal actual, string message)
        {
            if (intended >= actual)
            {
                Notification.Pass(message);
            }
            else
            {
                Notification.Fail(message);
            }
        }
    }

    public class StringAssert
    {
        public static void Contains(string needle, string haystack, string message)
        {
            if (haystack.Contains(needle))
            {
                Notification.Pass(message);
            }
            else
            {
                Notification.Fail(message);
            }
        }
        public static void StartsWith(string needle, string haystack, string message)
        {
            if (haystack.StartsWith(needle))
            {
                Notification.Pass(message);
            }
            else
            {
                Notification.Fail(message);
            }
        }
        public static void EndsWith(string needle, string haystack, string message)
        {
            if (haystack.EndsWith(needle))
            {
                Notification.Pass(message);
            }
            else
            {
                Notification.Fail(message);
            }
        }
        public static void AreEqualIgnoringCase(string needle, string haystack, string message)
        {
            if (haystack.ToLower().Equals(needle.ToLower()))
            {
                Notification.Pass(message);
            }
            else
            {
                Notification.Fail(message);
            }
        }
    }
}
