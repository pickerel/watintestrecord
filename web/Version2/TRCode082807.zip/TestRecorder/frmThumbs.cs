using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DemoApp
{
    public delegate void ThumbImageClick(string BrowserName);
    public partial class frmThumbs : Form
    {
        /// <summary>
        /// To notify the frmMian of a picturebox click event
        /// to switch tabs (toolstripbuttons)
        /// </summary>
        public event ThumbImageClick ThumbImageClickEvent;

        private PictureBox m_pPic = null;
        private Label m_pLbl = null;
        private const int m_ThumbSize = 120;
        private const int m_iGap = 5;
        private int m_iLastTopPos = 5;

        public frmThumbs()
        {
            InitializeComponent();
        }

        public void AddNewThumb(string Name,string Text, string Tooltiptext,Image IconImage, Image ThumbImage, bool Selected)
        {
            try
            {
                Label lbl = new Label();
                lbl.AutoSize = false;
                lbl.Cursor = System.Windows.Forms.Cursors.Hand;
                lbl.ImageAlign = ContentAlignment.MiddleRight;
                lbl.TextAlign = ContentAlignment.MiddleLeft;
                lbl.BackColor = System.Drawing.SystemColors.Control;
                lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
                lbl.Location = new System.Drawing.Point(m_iGap, m_iLastTopPos);
                lbl.Name = Name;
                lbl.Size = new System.Drawing.Size(m_ThumbSize, 22);
                lbl.Text = Text;
                if(IconImage != null)
                    lbl.Image = IconImage;
                lbl.Click += new EventHandler(lbl_Click);

                if (Selected)
                {
                    if (m_pLbl != null)
                        m_pLbl.BackColor = SystemColors.Control;
                    lbl.BackColor = System.Drawing.Color.LightGreen;
                }
                
                PictureBox pic = new PictureBox();
                pic.Cursor = System.Windows.Forms.Cursors.Hand;
                pic.Location = new System.Drawing.Point(m_iGap, m_iLastTopPos + lbl.Height);
                pic.Name = Name;
                pic.Size = new System.Drawing.Size(m_ThumbSize, m_ThumbSize);
                if(ThumbImage != null)
                    pic.Image = ThumbImage;
                pic.Click += new System.EventHandler(this.picThumb_Click);

                this.Controls.Add(lbl);
                this.Controls.Add(pic);

                if (Selected)
                {
                    m_pPic = pic;
                    m_pLbl = lbl;
                }
                //To activate tooltips , 
                //Uncomment line below
                //toolTip1.Active = true;
                
                //and replace instances of 
                // //toolTip1.SetToolTip( with toolTip1.SetToolTip(
                //toolTip1.SetToolTip(m_pPic, Tooltiptext);
                //toolTip1.SetToolTip(m_pLbl, Tooltiptext);

                m_iLastTopPos += (m_ThumbSize + m_iGap + lbl.Height);
            }
            catch (Exception ee)
            {
                AllForms.m_frmLog.AppendToLog("AddNewThumb\r\n" + ee.ToString());
            }
        }

        void lbl_Click(object sender, EventArgs e)
        {
            if (sender is Label)
            {
                if (m_pLbl != null)
                    m_pLbl.BackColor = SystemColors.Control;
                m_pLbl = (Label)sender;
                m_pPic = FindPictureBox(m_pLbl.Name);
                if (m_pLbl != null)
                    m_pLbl.BackColor = Color.LightGreen;

                if( (m_pPic != null) && (ThumbImageClickEvent != null) )
                    ThumbImageClickEvent(m_pPic.Name);
            }
        }

        public void UpdateThumb(string Name, string Text, string Tooltiptext, Image IconImage, Image ThumbImage)
        {
            try
            {
                //Updating the current one
                if ((m_pPic != null) && (m_pPic.Name == Name))
                {
                    if(ThumbImage != null)
                        m_pPic.Image = ThumbImage;
                    if (m_pLbl != null)
                    {
                        if (!string.IsNullOrEmpty(Text))
                            m_pLbl.Text = Text;
                        if (IconImage != null)
                            m_pLbl.Image = IconImage;
                        //toolTip1.SetToolTip(m_pLbl, Tooltiptext);
                    }
                    //toolTip1.SetToolTip(m_pPic, Tooltiptext);
                    return;
                }

                PictureBox pic = FindPictureBox(Name);
                if (pic != null)
                {
                    if(ThumbImage != null)
                        pic.Image = ThumbImage;
                    //toolTip1.SetToolTip(m_pPic, Tooltiptext);
                }

                Label lbl = FindLabel(Name);
                if (lbl != null)
                {
                    if (!string.IsNullOrEmpty(Text))
                        lbl.Text = Text;
                    if (IconImage != null)
                        lbl.Image = IconImage;
                    //toolTip1.SetToolTip(m_pLbl, Tooltiptext);
                }
            }
            catch (Exception ee)
            {
                AllForms.m_frmLog.AppendToLog("UpdateThumb\r\n" + ee.ToString());
            }
        }

        public void SetLabelIcon(string Name, Image IconImage)
        {
            if (IconImage == null)
                return;
            foreach (Control ctl in Controls)
            {
                if ((ctl.Name == Name) && (ctl is Label))
                {
                    ((Label)ctl).Image = IconImage;
                    return;
                }
            }
        }

        public void RemoveThumb(string Name, string SelectedName)
        {
            //Remove a picturebox and adjust the rest
            int ilast = m_iLastTopPos;

            try
            {
                if (!string.IsNullOrEmpty(SelectedName))
                {
                    m_pPic = FindPictureBox(SelectedName);
                    if (m_pLbl != null)
                        m_pLbl.BackColor = SystemColors.Control;
                    m_pLbl = FindLabel(SelectedName);
                    if (m_pLbl != null)
                        m_pLbl.BackColor = Color.LightGreen;
                }

                m_iLastTopPos = 3;
                PictureBox pic = null;
                Label lbl = null;
                try
                {
                    pic = FindPictureBox(Name);
                    /*
                     * If the image is not cleared
                     * an InvalidArgumentException is thrown????
                     */
                    pic.Image = null;
                    this.Controls.Remove(pic);
                    pic.Dispose();
                    pic = null;

                    lbl = FindLabel(Name);
                    lbl.Image = null;
                    this.Controls.Remove(lbl);
                    lbl.Dispose();
                    lbl = null;
                }
                catch (Exception eee)
                {
                    AllForms.m_frmLog.AppendToLog("Failed removing thumb\r\n" + eee.ToString());
                }

                int count = this.Controls.Count;
                for (int i = 0; i < count; i++)
                {
                    if (this.Controls[i] is PictureBox)
                    {
                        lbl = FindLabel(this.Controls[i].Name);
                        if (lbl != null)
                            lbl.Location = new Point(m_iGap, m_iLastTopPos);
                        this.Controls[i].Location = new Point(m_iGap, m_iLastTopPos + lbl.Height);
                        m_iLastTopPos += (m_ThumbSize + m_iGap + lbl.Height);
                    }
                }
            }
            catch (Exception ee)
            {
                AllForms.m_frmLog.AppendToLog("RemoveThumb\r\n" + ee.ToString());
            }
        }

        public void SwitchThumb(string NewName)
        {
            try
            {
                if (m_pLbl != null)
                    m_pLbl.BackColor = SystemColors.Control;
                foreach (Control ctl in Controls)
                {
                    if (ctl.Name == NewName)
                    {
                        if (ctl is PictureBox)
                            m_pPic = (PictureBox)ctl;
                        if (ctl is Label)
                            m_pLbl = (Label)ctl;
                    }
                }
                if (m_pLbl != null)
                    m_pLbl.BackColor = Color.LightGreen;
            }
            catch (Exception ee)
            {
                AllForms.m_frmLog.AppendToLog("SwitchThumb\r\n" + ee.ToString());
            }
        }

        private PictureBox FindPictureBox(string name)
        {
            foreach (Control ctl in Controls)
            {
                if ((ctl.Name == name) && (ctl is PictureBox))
                {
                    return (PictureBox)ctl;
                }
            }
            return null;
        }

        private Label FindLabel(string name)
        {
            foreach (Control ctl in Controls)
            {
                if ((ctl.Name == name) && (ctl is Label))
                {
                    return (Label)ctl;
                }
            }
            return null;
        }

        private void picThumb_Click(object sender, EventArgs e)
        {
            try
            {
                if (sender is PictureBox)
                {
                    //Change the border style of the last one
                    if (m_pLbl != null)
                        m_pLbl.BackColor = SystemColors.Control;
                    //Get the current one
                    m_pPic = (PictureBox)sender;
                    
                    m_pLbl = FindLabel(m_pPic.Name);
                    if (m_pLbl != null)
                        m_pLbl.BackColor = Color.LightGreen;
                    
                    if (ThumbImageClickEvent != null)
                        ThumbImageClickEvent(m_pPic.Name);
                }
            }
            catch (Exception ee)
            {
                AllForms.m_frmLog.AppendToLog("frmThumbs - picThumb_Click\r\n" + ee.ToString());
            }
        }

        private void frmThumbs_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                this.Hide();
            }
        }
    }
}