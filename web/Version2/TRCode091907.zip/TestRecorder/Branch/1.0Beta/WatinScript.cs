using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.CodeDom;
using System.CodeDom.Compiler;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Xml;
using IfacesEnumsStructsClasses;
using System.Drawing;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace DemoApp
{
    public class WatinScript

    {
        private StringBuilder sbCode = new StringBuilder();
        public StringBuilder sbKeys = new StringBuilder();
        private DateTime LastKeyTime = DateTime.MinValue;
        public RichTextBox rtbTarget = null;
        public csExWB.cEXWB MainBrowser = null;
        public ListBox lbTestList = null;
        public bool UnsavedScript = false;
        private bool DeclaredPopup = false;
        private bool DeclaredAlertHandler = false;
        private bool DeclaredConfirmHandler = false;
        private bool DeclaredLogonHandler = false;
        public bool Recording = false;
        public System.Collections.Specialized.NameValueCollection RecordedTests = new System.Collections.Specialized.NameValueCollection();

        // settings
        public string BaseIEName = "ie";
        public string PopupIEName = "iepopup";
        public double TypingTime = 1000;
        public bool WarnWhenUnsaved = true;
        public enum ScriptFormats { Snippet, Console, NUnit, MBUnit, VS2005Library }
        public ScriptFormats ScriptFormatting = ScriptFormats.Snippet;
        public string CompilePath = Path.GetDirectoryName(Application.ExecutablePath);
        public string TestName = "WatiNTest";
        public System.Drawing.Font ScriptWindowFont;
        public System.Drawing.Color DOMHighlightColor = Color.Yellow;
        public string NUnitFrameworkPath = "";
        public string MBUnitFrameworkPath = "";
        public string VS2005FrameworkPath = "";
        public System.Collections.Specialized.StringCollection ReferencedAssemblies = new System.Collections.Specialized.StringCollection();
        public bool HideDOSWindow = false;

        // generic constructor
        public WatinScript()
        {
            //
        }

        public int GetTestIndex(string NameOfTest)
        {
            int result = -1;
            for (int i = 0; i < RecordedTests.Count; i++)
            {
                if (RecordedTests.GetKey(i)==NameOfTest)
                {
                    result = i;
                    break;
                }
            }
            return result;
        }

        #region Settings Load/Save

        public void LoadSettings()
        {
            Settings _settings = null;

            try
            {
                _settings = new Settings();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading settings: "+ex.Message);
                return;
            }
            
            BaseIEName = _settings.GetSetting("BaseIEName", "ie");
            PopupIEName = _settings.GetSetting("PopupIEName", "iepopup");
            TypingTime = Convert.ToDouble(_settings.GetSetting("TypingTime", "1000"));
            WarnWhenUnsaved = _settings.GetSetting("WarnWhenUnsaved", 1) == 1 ? true : false;
            HideDOSWindow = _settings.GetSetting("HideDOSWindow", 1) == 1 ? true : false;
            CompilePath = _settings.GetSetting("CompilePath", AppDirectory);
            TestName = _settings.GetSetting("TestName", "WatiNTest");
            DOMHighlightColor = Color.FromName(_settings.GetSetting("DOMHighlightColor", "Yellow"));
            NUnitFrameworkPath = _settings.GetSetting("NUnitFrameworkPath", "");
            MBUnitFrameworkPath = _settings.GetSetting("MBUnitFrameworkPath", "");
            VS2005FrameworkPath = _settings.GetSetting("VS2005FrameworkPath", "");
            ScriptFormatting = (ScriptFormats)System.Enum.Parse(typeof(ScriptFormats), _settings.GetSetting("ScriptFormatting", "Snippet"), true);

            string strAssemblies = _settings.GetSetting("ReferencedAssemblies", "");
            string[] arrAssemblies = strAssemblies.Split(",".ToCharArray());
            for (int i = 0; i < arrAssemblies.Length; i++)
            {
                ReferencedAssemblies.Add(arrAssemblies[i]);
            }

            string _fontName = _settings.GetSetting("FontName", rtbTarget.Font.FontFamily.Name);
            float _fontSize = float.Parse(_settings.GetSetting("FontSize", rtbTarget.Font.Size.ToString()));
            if (_fontName=="")
            {
                ScriptWindowFont = rtbTarget.Font;
            }
            else
            {
                ScriptWindowFont = new Font(_fontName,  _fontSize);
                rtbTarget.Font = ScriptWindowFont;
                lbTestList.Font = ScriptWindowFont;
            }
        }

        public void SaveSettings()
        {
            Settings _settings = null;

            try
            {
                _settings = new Settings();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading settings: " + ex.Message);
                return;
            }

            try
            {
                _settings.PutSetting("BaseIEName", BaseIEName);
                _settings.PutSetting("PopupIEName", PopupIEName);
                _settings.PutSetting("TypingTime", TypingTime.ToString());
                _settings.PutSetting("WarnWhenUnsaved", WarnWhenUnsaved ? 1 : 0);
                _settings.PutSetting("HideDOSWindow", HideDOSWindow ? 1 : 0);
                _settings.PutSetting("CompilePath", CompilePath);
                _settings.PutSetting("TestName", TestName);
                _settings.PutSetting("DOMHighlightColor", DOMHighlightColor.ToKnownColor().ToString());
                _settings.PutSetting("NUnitFrameworkPath", NUnitFrameworkPath);
                _settings.PutSetting("MBUnitFrameworkPath", MBUnitFrameworkPath);
                _settings.PutSetting("VS2005FrameworkPath", VS2005FrameworkPath);
                _settings.PutSetting("ScriptFormatting", System.Enum.GetName(typeof(ScriptFormats), ScriptFormatting));
                _settings.PutSetting("FontName", rtbTarget.Font.FontFamily.Name);
                _settings.PutSetting("FontSize", rtbTarget.Font.Size.ToString());

                StringBuilder sbAssemblies = new StringBuilder();
                for (int i = 0; i < ReferencedAssemblies.Count; i++)
                {
                    sbAssemblies.Append("," + ReferencedAssemblies[i]);
                }
                sbAssemblies.Remove(0, 1);
                _settings.PutSetting("ReferencedAssemblies", sbAssemblies.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving settings: "+ex.Message);
            }

        }

        #endregion

        #region Script Save/Load/Prepare

        public void SaveScript(string Filename, ScriptFormats Formatting)
        {
            // write to file
            string code = PrepareScript(Formatting, rtbTarget.Text);

            if (System.IO.File.Exists(Filename))
            {
                System.IO.File.Delete(Filename);
            }

            try
            {
                System.IO.StreamWriter strm = new StreamWriter(Filename);
                strm.Write(code);
                strm.Close();

                UnsavedScript = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Save Error - Not Saved", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void LoadScript(string Filename)
        {
            if (!System.IO.File.Exists(Filename))
            {
                MessageBox.Show("File " + Filename + " does not exist", "File Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (UnsavedScript)
            {
                if (MessageBox.Show("You have an unsaved script, and loading will erase it.  Erase and continue loading?", "Confirmation",MessageBoxButtons.YesNo)==DialogResult.No)
                {
                    return;
                }
            }

            try
            {
                System.IO.StreamReader strm = new StreamReader(Filename);
                string[] arrCode = strm.ReadToEnd().Split(Environment.NewLine.ToCharArray());
                strm.Close();

                RecordedTests.Clear();

                string currentname = "";
                StringBuilder code = new StringBuilder();
                for (int i = 0; i < arrCode.Length; i++)
                {
                    if (arrCode[i].Contains("// TESTSTART "))
                    {
                        currentname = arrCode[i].Substring(13, arrCode[i].Length - 13);
                        continue;
                    }
                    if (arrCode[i].Contains("// TESTEND"))
                    {
                        RecordedTests.Add(currentname, code.ToString());
                        code.Length = 0;
                        currentname = "";
                        continue;
                    }
                    if (currentname != "")
                    {
                        code.Append(arrCode[i] + Environment.NewLine);
                    }
                }

                UnsavedScript = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private string PrepareScript(ScriptFormats Formatting, string Code)
        {
            StringBuilder sbResult = new StringBuilder();
            sbResult.Append("using System;" + Environment.NewLine);
            sbResult.Append("using System.IO;" + Environment.NewLine);
            sbResult.Append("using System.Threading;" + Environment.NewLine);
            sbResult.Append("using WatiN.Core;" + Environment.NewLine);
            sbResult.Append("using WatiN.Core.DialogHandlers;" + Environment.NewLine);
            sbResult.Append("using WatiN.Core.Exceptions;" + Environment.NewLine);
            sbResult.Append("using WatiN.Core.Interfaces;" + Environment.NewLine);
            sbResult.Append("using WatiN.Core.Logging;" + Environment.NewLine);
            if (Formatting==ScriptFormats.Console)
            {
                sbResult.Append(GetAssertCode(true));
            }
            else if (Formatting == ScriptFormats.MBUnit)
            {
                sbResult.Append("using MbUnit.Framework;" + Environment.NewLine);
            }
            else if (Formatting == ScriptFormats.VS2005Library)
            {
                sbResult.Append("using Microsoft.VisualStudio.TestTools.UnitTesting;" + Environment.NewLine);
            }
            else if (Formatting == ScriptFormats.NUnit)
            {
                sbResult.Append("using NUnit.Framework;" + Environment.NewLine);
            }
            sbResult.Append(Environment.NewLine);
            sbResult.Append("namespace WatiN.Tests {" + Environment.NewLine);

            if (Formatting==ScriptFormats.Snippet)
            {
                sbResult.Append("public class IETests {" + Environment.NewLine);
                for (int i = 0; i < RecordedTests.Count; i++)
                {
                    sbResult.Append("static void " + RecordedTests.GetKey(i) + "() {" + Environment.NewLine);
                    sbResult.Append("// TESTSTART " + RecordedTests.GetKey(i) + Environment.NewLine);
                    sbResult.Append(RecordedTests[i] + Environment.NewLine);
                    sbResult.Append("// TESTEND" + Environment.NewLine);
                    sbResult.Append("}" + Environment.NewLine);
                }
                sbResult.Append("}" + Environment.NewLine);
            }
                else if (Formatting==ScriptFormats.VS2005Library)
                {
                    sbResult.Append("[TestClass]" + Environment.NewLine);
                    sbResult.Append("public class IETests {" + Environment.NewLine);
                    for (int i = 0; i < RecordedTests.Count; i++)
                    {
                        sbResult.Append("[TestMethod]" + Environment.NewLine);
                        sbResult.Append("public void " + RecordedTests.GetKey(i) + "() {" + Environment.NewLine);
                        sbResult.Append("// TESTSTART " + RecordedTests.GetKey(i) + Environment.NewLine);
                        sbResult.Append(RecordedTests[i] + Environment.NewLine);
                        sbResult.Append("// TESTEND" + Environment.NewLine);
                        sbResult.Append("}" + Environment.NewLine);
                    }
                    sbResult.Append("}" + Environment.NewLine);
                }
            else if (Formatting==ScriptFormats.NUnit)
            {
                sbResult.Append("[TestFixture]"+Environment.NewLine);
                sbResult.Append("public class IETests {" + Environment.NewLine);
                for (int i = 0; i < RecordedTests.Count; i++)
                {
                    sbResult.Append("[Test]" + Environment.NewLine);
                    sbResult.Append("public void "+RecordedTests.GetKey(i)+"() {" + Environment.NewLine);
                    sbResult.Append("// TESTSTART " + RecordedTests.GetKey(i) + Environment.NewLine);
                    sbResult.Append(RecordedTests[i] + Environment.NewLine);
                    sbResult.Append("// TESTEND" + Environment.NewLine);
                    sbResult.Append("}" + Environment.NewLine);
                }
                sbResult.Append("}" + Environment.NewLine);
            }
            else if (Formatting==ScriptFormats.MBUnit)
            {
                sbResult.Append("[TestFixture(ApartmentState = ApartmentState.STA)]"+Environment.NewLine);
                sbResult.Append("public class IETests {" + Environment.NewLine);
                for (int i = 0; i < RecordedTests.Count; i++)
                {
                    sbResult.Append("[Test]" + Environment.NewLine);
                    sbResult.Append("public void "+RecordedTests.GetKey(i)+"() {" + Environment.NewLine);
                    sbResult.Append("// TESTSTART " + RecordedTests.GetKey(i) + Environment.NewLine);
                    sbResult.Append(RecordedTests[i] + Environment.NewLine);
                    sbResult.Append("// TESTEND" + Environment.NewLine);
                    sbResult.Append("}" + Environment.NewLine);
                }
                sbResult.Append("}" + Environment.NewLine);
            }
            else if (Formatting==ScriptFormats.Console)
            {
                sbResult.Append("public class IETests {" + Environment.NewLine);
                sbResult.Append("[STAThread]" + Environment.NewLine);
                sbResult.Append("static void Main()" + Environment.NewLine);
                sbResult.Append("{" + Environment.NewLine);
                
                for (int i = 0; i < RecordedTests.Count; i++)
                {
                    sbResult.Append(RecordedTests.GetKey(i) + "();" + Environment.NewLine);
                }

                sbResult.Append("System.Environment.Exit(0);" + Environment.NewLine);
                sbResult.Append("}" + Environment.NewLine);

                for (int i = 0; i < RecordedTests.Count; i++)
                {
                    sbResult.Append("static void " + RecordedTests.GetKey(i) + "() {" + Environment.NewLine);
                    sbResult.Append("// TESTSTART " + RecordedTests.GetKey(i) + Environment.NewLine);
                    sbResult.Append(RecordedTests[i] + Environment.NewLine);
                    sbResult.Append("// TESTEND" + Environment.NewLine);
                    sbResult.Append("}" + Environment.NewLine);
                }

                sbResult.Append("}" + Environment.NewLine);
                sbResult.Append("}" + Environment.NewLine);
                sbResult.Append(Environment.NewLine);
                sbResult.Append(GetAssertCode(false));
            }

            if (Formatting != ScriptFormats.Console)
            {
                sbResult.Append("}" + Environment.NewLine);
            }
            
            return sbResult.ToString();
        }

        #endregion

        #region Add Line To Script

        public void AddGoto(string IEName, string URL)
        {
            AddScriptLine(IEName+".GoTo(\"" + URL + "\");");
        }

        public void AddBack()
        {
            AddScriptLine(BaseIEName+".Back();");
        }

        public void AddForward()
        {
            AddScriptLine(BaseIEName + ".Forward();");
        }

        public void AddRefresh()
        {
            AddScriptLine(BaseIEName + ".Refresh();");
        }

        public void AddTyping(string IEName, IHTMLElement ActiveElement)
        {
            AddAction(IEName, ActiveElement, "TypeText(\"" + sbKeys.ToString() + "\");");
            sbKeys.Length = 0;
        }

        public void AddClick(string IEName, IHTMLElement ActiveElement)
        {
            AddAction(IEName, ActiveElement, "Click();");
        }

        public void AddAlertHandler(string IEName)
        {
            if (DeclaredAlertHandler)
            {
                AddScriptLine("adhdl = new AlertDialogHandler();");
            }
            else
            {
                AddScriptLine("AlertDialogHandler adhdl = new AlertDialogHandler();");
            }
            
            AddScriptLine(IEName+".AddDialogHandler(adhdl);");
            AddScriptLine("adhdl.OKButton.Click();");
        }

        public void AddConfirmHandler(string IEName, DialogResult DlogResult)
        {
            if (DeclaredConfirmHandler)
            {
                AddScriptLine("cdhdl = new ConfirmDialogHandler();");
            }
            else
            {
                AddScriptLine("ConfirmDialogHandler cdhdl = new ConfirmDialogHandler();");
            }
            
            AddScriptLine(IEName+".AddDialogHandler(cdhdl);");

            if (DlogResult==DialogResult.OK)
            {
                AddScriptLine("cdhdl.OKButton.Click();");
            }
            else
            {
                AddScriptLine("cdhdl.CancelButton.Click();");
            }
        }

        public void AddPopup(string IEName, string URL)
        {
            if (DeclaredPopup)
            {
                AddScriptLine(IEName+" = IE.AttachToBrowser(Find.ByUrl(\"" + URL + "\"));");
            }
            else
            {
                AddScriptLine("IE "+IEName+" = IE.AttachToBrowser(Find.ByUrl(\"" + URL + "\"));");
            }
        }

        public void AddClosePopup(string IEName)
        {
            AddScriptLine(IEName+".Close();");
        }

        public void AddLoginDialog(string IEName, string Username, string Password)
        {
            if (DeclaredLogonHandler)
            {
                AddScriptLine("dhdlLogon = LogonDialogHandler(\"" + Username + "\",\"" + Password + "\");");
            }
            else
            {
                AddScriptLine("LogonDialogHandler dhdlLogon = LogonDialogHandler(\"" + Username + "\",\"" + Password + "\");");
            }
            
            AddScriptLine(IEName+".AddDialogHandler(dhdlLogon);");
        }

        public void AddScriptLine(string Line)
        {
            if (!Recording)
            {
                return;
            }

            UnsavedScript = true;

            sbCode.Length = 0;
            sbCode.Append(rtbTarget.Text);

            if (sbCode.Length == 0)
            {
                sbCode.Append("IE "+BaseIEName+" = new IE(\""+MainBrowser.LocationUrl+"\");" + System.Environment.NewLine);
            }

            sbCode.Append(Line + System.Environment.NewLine);

            // send to registered target
            if (rtbTarget != null)
            {
                rtbTarget.Text = sbCode.ToString();
            }
        }

        public void AddKeys(bool Shifted, Keys keycode)
        {
            string strKey = keycode.ToString();
            if (keycode == Keys.Space)
            {
                strKey = " ";
            }
            else if (keycode == Keys.Enter)
            {
                strKey = "{enter}";
            }
            else if (keycode == Keys.Tab)
            {
                strKey = "{tab}";
            }
            else if (keycode == Keys.Up)
            {
                strKey = "{up}";
            }
            else if (keycode == Keys.Down)
            {
                strKey = "{down}";
            }
            else if (keycode == Keys.Left)
            {
                strKey = "{left}";
            }
            else if (keycode == Keys.Right)
            {
                strKey = "{right}";
            }
            else if (keycode == Keys.Back)
            {
                strKey = "{back}";
            }

            if (Shifted)
            {
                sbKeys.Append(strKey);
            }
            else
            {
                sbKeys.Append(strKey.ToLower());
            }
        }

        public string ActiveElementAttribute(IHTMLElement element, string AttributeName)
        {
            string strValue = element.getAttribute(AttributeName, 0) as string;
            if (strValue == null)
            {
                strValue = "";
            }
            return strValue;
        }

        public void AddAction(string BrowserName, IHTMLElement element, string Action)
        {
            string strElement = DetermineFindMethod(BrowserName, element);
            strElement += "." + Action;
            AddScriptLine(strElement);
        }

        public string DetermineFindMethod(string BrowserName, IHTMLElement element)
        {
            //IE.item(findmethod).action
            string line = BrowserName + ".";
            string tagtype = "";

            if (element.tagName.ToLower() == "input")
            {
                tagtype = ActiveElementAttribute(element, "type").ToLower();
                switch (tagtype)
                {
                    case "button": line += "Button"; break;
                    case "submit": line += "Button"; break;
                    case "reset": line += "Button"; break;
                    case "radio": line += "RadioButton"; break;
                    case "checkbox": line += "CheckBox"; break;
                    case "file": line += "FileUpload"; break;
                    default: line += "TextField"; break;
                }
            }
            else
            {
                switch (element.tagName.ToLower())
                {
                    case "select": line += "SelectList"; break;
                    case "span": line += "Span"; break;
                    case "div": line += "Div"; break;
                    case "a": line += "Link"; break;
                    case "img": line += "Image"; break;
                    case "form": line += "Form"; break;
                    case "frame": line += "Frame"; break;
                    case "p": line += "Para"; break;
                    case "table": line += "Table"; break;
                    case "tbody": line += "TableBody"; break;
                    case "tr": line += "TableRow"; break;
                    case "td": line += "TableCell"; break;
                    case "textarea": line += "TextField"; break;
                    default: return "// Unknown Element: "+element.tagName;
                }
            }
            

            line += "(";

            // order: id, name, href, url, src, value, style, (inner)text
            string linepart = ActiveElementAttribute(element, "id");
            if (linepart != "")
            {
                line += "Find.ById(\"" + linepart;
            }
            else
            {
                linepart = ActiveElementAttribute(element, "name");
                if (linepart != "")
                {
                    line += "Find.ByName(\"" + linepart;
                }
                else
                {
                    linepart = ActiveElementAttribute(element, "href");
                    if (linepart != "")
                    {
                        line += "Find.ByUrl(\"" + linepart;
                    }
                    else
                    {
                    	linepart = ActiveElementAttribute(element, "url");
                        if (linepart != "")
                        {
                            line += "Find.ByUrl(\"" + linepart;
                        }
                        else
                        {
                            linepart = ActiveElementAttribute(element, "src");
                            if (linepart != "")
                            {
                                line += "Find.BySrc(\"" + linepart;
                            }
                            else
                            {
                                linepart = ActiveElementAttribute(element, "value");
                                if (linepart != "")
                                {
                                    line += "Find.ByValue(\"" + linepart;
                                }
                                else
                                {
                                    linepart = ActiveElementAttribute(element, "style");
                                    if (linepart != "")
                                    {
                                        line += "Find.ByStyle(\"" + linepart;
                                    }
                                    else
                                    {
                                        linepart = ActiveElementAttribute(element, "innerText");
                                        if (linepart != "")
                                        {
                                            line += "Find.ByText(\"" + linepart;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            line += "\"))";


            return line;
        }
#endregion

        #region CompileScript

        private string GetAssertCode(bool UsingOnly)
        {
            StringBuilder sbAssertCode = new StringBuilder();
            StreamReader reader = new StreamReader(Path.Combine(AppDirectory, "assertCompare.cs"));
            string[] arrAssertCode = reader.ReadToEnd().Split(Environment.NewLine.ToCharArray());
            for (int i = 0; i < arrAssertCode.Length; i++)
            {
                if (UsingOnly && arrAssertCode[i].ToLower().StartsWith("using "))
                {
                    sbAssertCode.Append(arrAssertCode[i] + Environment.NewLine);
                }
                else if (UsingOnly == false && arrAssertCode[i].ToLower().StartsWith("using ") == false)
                {
                    sbAssertCode.Append(arrAssertCode[i] + Environment.NewLine);
                }
            }
            reader.Close();

            return sbAssertCode.ToString();
        }

        private string ExecutableFilename
        {
            get
            {
                if (CompilePath==null)
                {
                    CompilePath = Path.GetDirectoryName(Application.ExecutablePath);
                    if (CompilePath.Contains("TestDriven"))
                    {
                        CompilePath = @"C:\Development\TestRecorder\bin\Debug\";
                    }
                }
                
                return Path.Combine(CompilePath, TestName + ".exe");
            }
        }

        private string AppDirectory
        {
            get
            {
                string directory = Path.GetDirectoryName(Application.ExecutablePath);
                if (directory.Contains("TestDriven"))
                {
                    directory = @"C:\Development\TestRecorder\bin\Debug\";
                }
                return directory;
            }
        }

        public string CompileScript(bool RunScript)
        {
            return CompileScript(rtbTarget.Text, RunScript);
        }

        public string CompileScript(string ScriptCode, bool RunScript)
        {
            if (ScriptCode=="")
            {
                return "No code to compile";
            }

            CompilePath = Path.GetDirectoryName(CompilePath);
            if (!File.Exists(CompilePath))
            {
                return "Compile Path (" + CompilePath + ") does not exist.  Please modify it in the Settings.";
            }

            StringBuilder sbErrors = new StringBuilder();

            List<string> usings = new List<string>();				// #using directives
            List<string> imports = new List<string>();			// #import directives
            StringWriter source = new StringWriter();				// For writing script file

            CompilerParameters cps = new CompilerParameters();
            cps.OutputAssembly = ExecutableFilename;
            cps.GenerateExecutable = true;
            cps.IncludeDebugInformation = true;

            string NetPath = RuntimeEnvironment.GetRuntimeDirectory();
            imports.Add(Path.Combine(NetPath, "System.dll"));
            imports.Add(Path.Combine(NetPath,"System.Data.dll"));
            imports.Add(Path.Combine(NetPath,"System.XML.dll"));
            imports.Add(Path.Combine(AppDirectory, "WatiN.Core.dll"));

            for (int i = 0; i < ReferencedAssemblies.Count; i++)
            {
                imports.Add(ReferencedAssemblies[i]);
            }

            ScriptCode = PrepareScript(ScriptFormatting, ScriptCode);
            if (ScriptFormatting == ScriptFormats.NUnit)
            {
                if (NUnitFrameworkPath=="")
                {
                    return "NUnit Framework Path cannot be blank.  Please modify it in the Settings.";
                }

                imports.Add(NUnitFrameworkPath);

                cps.MainClass = TestName;
                cps.OutputAssembly = System.IO.Path.ChangeExtension(cps.OutputAssembly, ".dll");
                System.IO.File.Copy(Path.Combine(AppDirectory, "NUnitConfig.xml"), cps.OutputAssembly + ".config", true);
                cps.GenerateExecutable = false;
            }
            else if (ScriptFormatting == ScriptFormats.MBUnit)
            {
                if (MBUnitFrameworkPath == "")
                {
                    return "MBUnit Framework Path cannot be blank.  Please modify it in the Settings.";
                }

                imports.Add(MBUnitFrameworkPath);

                cps.MainClass = TestName;
                cps.OutputAssembly = System.IO.Path.ChangeExtension(cps.OutputAssembly, ".dll");
                if (File.Exists(Path.Combine(AppDirectory, "MbUnitConfig.xml")))
                {
                    System.IO.File.Copy(Path.Combine(AppDirectory, "MbUnitConfig.xml"), cps.OutputAssembly + ".config", true);
                }
                cps.GenerateExecutable = false;
            }
            else if (ScriptFormatting == ScriptFormats.VS2005Library)
            {
                imports.Add(VS2005FrameworkPath);

                cps.MainClass = TestName;
                cps.OutputAssembly = System.IO.Path.ChangeExtension(cps.OutputAssembly, ".dll");
                //System.IO.File.Copy(Path.Combine(AppDirectory, "VS2005.xml"), cps.OutputAssembly + ".testrunconfig", true);
                cps.GenerateExecutable = false;
            }
            else if (ScriptFormatting == ScriptFormats.Snippet)
            {
                ScriptCode = PrepareScript(ScriptFormats.Console, ScriptCode);
            }
                        
            StringWriter finalsource = new StringWriter();	// For building source code

            string[] arrCode = ScriptCode.Split(System.Environment.NewLine.ToCharArray());

            // Parse the source file
            for (int i = 0; i < arrCode.Length; i++)
            {
                string line = arrCode[i].Trim();
                // Check for certain directives
                if (line.StartsWith("#using"))
                {
                    if (line.Substring(line.Length - 1, 1) == ";")
                        line = line.Remove(line.Length - 1, 1);
                    usings.Add(line.Substring(6).Trim());
                }
                else if (line.StartsWith("#import"))
                {
                    imports.Add(line.Substring(7).Trim());
                }
                else if (line.StartsWith("#include"))
                {
                    int posStart = line.IndexOf('"') + 1;
                    int posEnd = line.LastIndexOf('"');
                    line = line.Substring(posStart, posEnd - posStart);

                    // If relative then convert to absolute based on application
                    if (!Path.IsPathRooted(line))
                        line = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), line);

                    // Open the file for reading and write it to the stream
                    using (StreamReader includefile = new StreamReader(line))
                    {
                        while (includefile.Peek() != -1)
                            source.WriteLine(includefile.ReadLine());
                        includefile.Close();
                        source.Flush();
                    }
                }
                else
                {
                    source.WriteLine(line);
                }
            }

            // Build the script file
            int prefixedLines = 0;

            //  Print the usings
            foreach (string use in usings)
            {
                finalsource.WriteLine("using {0};", use);
                prefixedLines++;
            }

            //  Dump the entire contents of the parsed file
            finalsource.WriteLine(source.ToString());

            //  We can now close the source stream
            source.Close();
            source.Dispose();

                      
            // Add dlls
            foreach (string dll in imports)
            {
                cps.ReferencedAssemblies.Add(dll);
            }
                

            // Compile the source code
            CompilerResults cr = null;
            try
            {
                Microsoft.CSharp.CSharpCodeProvider codeprovider = new Microsoft.CSharp.CSharpCodeProvider();
                cr = codeprovider.CompileAssemblyFromSource(cps, finalsource.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show("Compiler Error: "+ex.Message);
            }
            finally
            {
                // Close the final stream
                finalsource.Close();
                finalsource.Dispose();
            }
            
            // Check for errors
            if (cr.Errors.Count > 0)
            {
                // Has errors so display them
                foreach (CompilerError ce in cr.Errors)
                {
                    sbErrors.AppendFormat("{4} [{0}] at Line {1} Column {2}: {3}"+System.Environment.NewLine, ce.ErrorNumber, ce.Line - prefixedLines, ce.Column, ce.ErrorText, (ce.IsWarning) ? "Warning" : "Error");
                }
                System.Diagnostics.Debug.WriteLine(sbErrors.ToString());
                return sbErrors.ToString();
            }
            
            // copy WatiN and shdocvw to the same directory (for all cases)
            System.IO.File.Copy(Path.Combine(AppDirectory, "Interop.SHDocVw.dll"), Path.Combine(CompilePath, "Interop.SHDocVw.dll"), true);
            System.IO.File.Copy(Path.Combine(AppDirectory, "WatiN.Core.dll"), Path.Combine(CompilePath, "WatiN.Core.dll"), true);

            // MbUnit needs a few more files
            if (ScriptFormatting==ScriptFormats.MBUnit)
            {
                string mbunitpath = Path.GetDirectoryName(MBUnitFrameworkPath);
                System.IO.File.Copy(MBUnitFrameworkPath, Path.Combine(CompilePath, "MbUnit.Framework.dll"), true);
                System.IO.File.Copy(Path.Combine(mbunitpath, "QuickGraph.Algorithms.dll"), Path.Combine(CompilePath, "QuickGraph.Algorithms.dll"), true);
                System.IO.File.Copy(Path.Combine(mbunitpath, "QuickGraph.dll"), Path.Combine(CompilePath, "QuickGraph.dll"), true);
                System.IO.File.Copy(Path.Combine(mbunitpath, "Refly.dll"), Path.Combine(CompilePath, "Refly.dll"), true);
                System.IO.File.Copy(Path.Combine(mbunitpath, "TestFu.dll"), Path.Combine(CompilePath, "TestFu.dll"), true);
            }

            if (RunScript && (ScriptFormatting == ScriptFormats.Snippet || ScriptFormatting==ScriptFormats.Console))
            {
                try
                {
                    System.Diagnostics.ProcessStartInfo info = new System.Diagnostics.ProcessStartInfo(cps.OutputAssembly);
                    if (HideDOSWindow)
                    {
                        info.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                    }
                    System.Diagnostics.Process.Start(info);
                }
                catch (Exception e)
                {
                    return e.Message;
                }
            }

            return "";
        }

        #endregion
    }
}
