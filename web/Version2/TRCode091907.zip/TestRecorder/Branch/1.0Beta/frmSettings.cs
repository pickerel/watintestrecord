using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DemoApp
{
    public partial class frmSettings : Form
    {
        public frmSettings()
        {
            InitializeComponent();
        }

        public void ObjectToGUI(WatinScript script)
        {
            txtMainBrowserName.Text = script.BaseIEName;
            txtPopupBrowserName.Text = script.PopupIEName;
            txtCompilePath.Text = script.CompilePath;
            txtNUnitPath.Text = script.NUnitFrameworkPath;
            txtMBUnitPath.Text = script.MBUnitFrameworkPath;
            txtVS05Path.Text = script.VS2005FrameworkPath;
            numTypeTime.Value = Convert.ToDecimal(script.TypingTime);
            pnlDOMColor.BackColor = script.DOMHighlightColor;
            lblSourceFont.Font = script.ScriptWindowFont;
            chkWarnUnsaved.Checked = script.WarnWhenUnsaved;
            chkHideDOSWindow.Checked = script.HideDOSWindow;

            lbAssemblies.Items.Clear();
            for (int i = 0; i < script.ReferencedAssemblies.Count; i++)
            {
                lbAssemblies.Items.Add(script.ReferencedAssemblies[i]);
            }

            rbSnippet.Checked = false;
            rbConsole.Checked = false;
            rbNUnit.Checked = false;
            rbMBUnit.Checked = false;
            rbVS05Lib.Checked = false;

            switch (script.ScriptFormatting)
            {
                case WatinScript.ScriptFormats.Snippet: rbSnippet.Checked = true; break;
                case WatinScript.ScriptFormats.Console: rbConsole.Checked = true; break;
                case WatinScript.ScriptFormats.NUnit: rbNUnit.Checked = true; break;
                case WatinScript.ScriptFormats.MBUnit: rbMBUnit.Checked = true; break;
                case WatinScript.ScriptFormats.VS2005Library: rbVS05Lib.Checked = true; break;
            }
        }

        public void GUIToObject(WatinScript script)
        {
            script.BaseIEName = txtMainBrowserName.Text;
            script.PopupIEName = txtPopupBrowserName.Text;
            script.CompilePath = txtCompilePath.Text;
            script.NUnitFrameworkPath = txtNUnitPath.Text;
            script.MBUnitFrameworkPath = txtMBUnitPath.Text;
            script.VS2005FrameworkPath = txtVS05Path.Text;
            script.TypingTime = Convert.ToDouble(numTypeTime.Value);
            script.DOMHighlightColor = pnlDOMColor.BackColor;
            script.ScriptWindowFont = lblSourceFont.Font;
            script.WarnWhenUnsaved = chkWarnUnsaved.Checked;
            script.HideDOSWindow = chkHideDOSWindow.Checked;

            script.ReferencedAssemblies.Clear();
            for (int i = 0; i < lbAssemblies.Items.Count; i++)
            {
                script.ReferencedAssemblies.Add(lbAssemblies.Items[i].ToString());
            }

            if (rbNUnit.Checked)
            {
                script.ScriptFormatting = WatinScript.ScriptFormats.NUnit;
            }
            else if (rbMBUnit.Checked)
            {
                script.ScriptFormatting = WatinScript.ScriptFormats.MBUnit;
            }
            else if (rbVS05Lib.Checked)
            {
                script.ScriptFormatting = WatinScript.ScriptFormats.VS2005Library;
            }
            else if (rbConsole.Checked)
            {
                script.ScriptFormatting = WatinScript.ScriptFormats.Console;
            }
            else
            {
                script.ScriptFormatting = WatinScript.ScriptFormats.Snippet;
            }
        }

        private void btnDOMColor_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog()==DialogResult.Cancel)
            {
                return;
            }
            pnlDOMColor.BackColor = colorDialog1.Color;
        }

        private void btnCodeFont_Click(object sender, EventArgs e)
        {
            if (fontDialog1.ShowDialog()==DialogResult.Cancel)
            {
                return;
            }
            lblSourceFont.Font = fontDialog1.Font;
        }

        private void btnCompilePath_Click(object sender, EventArgs e)
        {
            if (fbCompilePathDialog.ShowDialog()==DialogResult.Cancel)
            {
                return;
            }
            txtCompilePath.Text = fbCompilePathDialog.SelectedPath+"\\";
        }

        private void btnFindAssembly_Click(object sender, EventArgs e)
        {
            openAssemblyDialog.InitialDirectory = System.Runtime.InteropServices.RuntimeEnvironment.GetRuntimeDirectory();
            if (openAssemblyDialog.ShowDialog()==DialogResult.OK)
            {
                txtAssembly.Text = openAssemblyDialog.FileName;
            }
        }

        private void btnAddAssembly_Click(object sender, EventArgs e)
        {
            if (txtAssembly.Text=="")
            {
                return;
            }
            lbAssemblies.Items.Add(txtAssembly.Text);
        }

        private void btnRemoveAssembly_Click(object sender, EventArgs e)
        {
            if (lbAssemblies.SelectedIndex==-1)
            {
                return;
            }
            lbAssemblies.Items.Remove(lbAssemblies.SelectedIndex);
        }

        private void btnNUnitPath_Click(object sender, EventArgs e)
        {
            if (openNUnitDialog.ShowDialog() == DialogResult.Cancel)
            {
                return;
            }

            if (!openNUnitDialog.FileName.ToLower().EndsWith("nunit.framework.dll"))
            {
                MessageBox.Show("Path must be to NUnit.Framework.dll");
                return;
            }

            txtNUnitPath.Text = openNUnitDialog.FileName;
        }

        private void btnMBUnitPath_Click(object sender, EventArgs e)
        {
            if (openMBUnitDialog.ShowDialog() == DialogResult.Cancel)
            {
                return;
            }

            if (!openNUnitDialog.FileName.ToLower().EndsWith("mbunit.framework.dll"))
            {
                MessageBox.Show("Path must be to MBUnit.Framework.dll");
                return;
            }

            txtMBUnitPath.Text = openMBUnitDialog.FileName;
        }

        private void btnVS05Path_Click(object sender, EventArgs e)
        {
            if (openVS05Dialog.ShowDialog() == DialogResult.Cancel)
            {
                return;
            }

            if (!openVS05Dialog.FileName.ToLower().EndsWith("microsoft.visualstudio.qualitytools.unittestframework.dll"))
            {
                MessageBox.Show("Path must be to Microsoft.VisualStudio.QualityTools.UnitTestFramework.dll");
                return;
            }

            txtVS05Path.Text = openVS05Dialog.FileName;
        }
    }
}