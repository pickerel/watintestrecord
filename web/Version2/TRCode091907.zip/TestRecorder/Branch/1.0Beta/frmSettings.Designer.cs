namespace DemoApp
{
    partial class frmSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSettings));
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.openNUnitDialog = new System.Windows.Forms.OpenFileDialog();
            this.fbCompilePathDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.pageGeneral = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblSourceFont = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.chkWarnUnsaved = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnCodeFont = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.label6 = new System.Windows.Forms.Label();
            this.btnDOMColor = new System.Windows.Forms.Button();
            this.pnlDOMColor = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.numTypeTime = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPopupBrowserName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtMainBrowserName = new System.Windows.Forms.TextBox();
            this.pageCompiler = new System.Windows.Forms.TabPage();
            this.rbVS05Lib = new System.Windows.Forms.RadioButton();
            this.btnMBUnitPath = new System.Windows.Forms.Button();
            this.txtMBUnitPath = new System.Windows.Forms.TextBox();
            this.rbMBUnit = new System.Windows.Forms.RadioButton();
            this.chkHideDOSWindow = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnRemoveAssembly = new System.Windows.Forms.Button();
            this.btnAddAssembly = new System.Windows.Forms.Button();
            this.btnFindAssembly = new System.Windows.Forms.Button();
            this.txtAssembly = new System.Windows.Forms.TextBox();
            this.lbAssemblies = new System.Windows.Forms.ListBox();
            this.btnNUnitPath = new System.Windows.Forms.Button();
            this.txtNUnitPath = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnCompilePath = new System.Windows.Forms.Button();
            this.rbNUnit = new System.Windows.Forms.RadioButton();
            this.rbConsole = new System.Windows.Forms.RadioButton();
            this.rbSnippet = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCompilePath = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnDone = new System.Windows.Forms.Button();
            this.openAssemblyDialog = new System.Windows.Forms.OpenFileDialog();
            this.openMBUnitDialog = new System.Windows.Forms.OpenFileDialog();
            this.btnVS05Path = new System.Windows.Forms.Button();
            this.txtVS05Path = new System.Windows.Forms.TextBox();
            this.openVS05Dialog = new System.Windows.Forms.OpenFileDialog();
            this.tabControl1.SuspendLayout();
            this.pageGeneral.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTypeTime)).BeginInit();
            this.pageCompiler.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // openNUnitDialog
            // 
            this.openNUnitDialog.FileName = "NUnit.Framework.dll";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.pageGeneral);
            this.tabControl1.Controls.Add(this.pageCompiler);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(561, 409);
            this.tabControl1.TabIndex = 24;
            // 
            // pageGeneral
            // 
            this.pageGeneral.Controls.Add(this.panel2);
            this.pageGeneral.Controls.Add(this.label10);
            this.pageGeneral.Controls.Add(this.label9);
            this.pageGeneral.Controls.Add(this.chkWarnUnsaved);
            this.pageGeneral.Controls.Add(this.label7);
            this.pageGeneral.Controls.Add(this.btnCodeFont);
            this.pageGeneral.Controls.Add(this.label6);
            this.pageGeneral.Controls.Add(this.btnDOMColor);
            this.pageGeneral.Controls.Add(this.pnlDOMColor);
            this.pageGeneral.Controls.Add(this.label5);
            this.pageGeneral.Controls.Add(this.numTypeTime);
            this.pageGeneral.Controls.Add(this.label2);
            this.pageGeneral.Controls.Add(this.txtPopupBrowserName);
            this.pageGeneral.Controls.Add(this.label1);
            this.pageGeneral.Controls.Add(this.txtMainBrowserName);
            this.pageGeneral.Location = new System.Drawing.Point(4, 22);
            this.pageGeneral.Name = "pageGeneral";
            this.pageGeneral.Padding = new System.Windows.Forms.Padding(3);
            this.pageGeneral.Size = new System.Drawing.Size(553, 383);
            this.pageGeneral.TabIndex = 0;
            this.pageGeneral.Text = "General";
            this.pageGeneral.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lblSourceFont);
            this.panel2.Location = new System.Drawing.Point(122, 150);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(144, 28);
            this.panel2.TabIndex = 35;
            // 
            // lblSourceFont
            // 
            this.lblSourceFont.AutoSize = true;
            this.lblSourceFont.Location = new System.Drawing.Point(3, 10);
            this.lblSourceFont.Name = "lblSourceFont";
            this.lblSourceFont.Size = new System.Drawing.Size(93, 13);
            this.lblSourceFont.TabIndex = 32;
            this.lblSourceFont.Text = "Source Code Font";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(232, 40);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(203, 13);
            this.label10.TabIndex = 34;
            this.label10.Text = "Variable name to use for a popup browser";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(232, 14);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(215, 13);
            this.label9.TabIndex = 33;
            this.label9.Text = "Variable name to use for the primary browser";
            // 
            // chkWarnUnsaved
            // 
            this.chkWarnUnsaved.AutoSize = true;
            this.chkWarnUnsaved.Location = new System.Drawing.Point(123, 216);
            this.chkWarnUnsaved.Name = "chkWarnUnsaved";
            this.chkWarnUnsaved.Size = new System.Drawing.Size(268, 17);
            this.chkWarnUnsaved.TabIndex = 5;
            this.chkWarnUnsaved.Text = "Warn when code is unsaved and window is closing";
            this.chkWarnUnsaved.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(229, 72);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(271, 13);
            this.label7.TabIndex = 31;
            this.label7.Text = "Milliseconds of time to wait after last key to record typing";
            // 
            // btnCodeFont
            // 
            this.btnCodeFont.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCodeFont.ImageIndex = 6;
            this.btnCodeFont.ImageList = this.imageList1;
            this.btnCodeFont.Location = new System.Drawing.Point(272, 155);
            this.btnCodeFont.Name = "btnCodeFont";
            this.btnCodeFont.Size = new System.Drawing.Size(148, 23);
            this.btnCodeFont.TabIndex = 4;
            this.btnCodeFont.Text = "Change Source Font...";
            this.btnCodeFont.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCodeFont.UseVisualStyleBackColor = true;
            this.btnCodeFont.Click += new System.EventHandler(this.btnCodeFont_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Fuchsia;
            this.imageList1.Images.SetKeyName(0, "Tick.bmp");
            this.imageList1.Images.SetKeyName(1, "Delete.bmp");
            this.imageList1.Images.SetKeyName(2, "Plus.bmp");
            this.imageList1.Images.SetKeyName(3, "Minus.bmp");
            this.imageList1.Images.SetKeyName(4, "Folder.bmp");
            this.imageList1.Images.SetKeyName(5, "Colour Scheme.bmp");
            this.imageList1.Images.SetKeyName(6, "Format-Font.bmp");
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 119);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 13);
            this.label6.TabIndex = 28;
            this.label6.Text = "Highlight Color";
            // 
            // btnDOMColor
            // 
            this.btnDOMColor.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDOMColor.ImageIndex = 5;
            this.btnDOMColor.ImageList = this.imageList1;
            this.btnDOMColor.Location = new System.Drawing.Point(272, 109);
            this.btnDOMColor.Name = "btnDOMColor";
            this.btnDOMColor.Size = new System.Drawing.Size(148, 23);
            this.btnDOMColor.TabIndex = 3;
            this.btnDOMColor.Text = "Change Color...";
            this.btnDOMColor.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDOMColor.UseVisualStyleBackColor = true;
            this.btnDOMColor.Click += new System.EventHandler(this.btnDOMColor_Click);
            // 
            // pnlDOMColor
            // 
            this.pnlDOMColor.BackColor = System.Drawing.Color.Yellow;
            this.pnlDOMColor.Location = new System.Drawing.Point(122, 109);
            this.pnlDOMColor.Name = "pnlDOMColor";
            this.pnlDOMColor.Size = new System.Drawing.Size(100, 23);
            this.pnlDOMColor.TabIndex = 26;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 77);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(112, 13);
            this.label5.TabIndex = 25;
            this.label5.Text = "Maximum Typing Time";
            // 
            // numTypeTime
            // 
            this.numTypeTime.Increment = new decimal(new int[] {
            250,
            0,
            0,
            0});
            this.numTypeTime.Location = new System.Drawing.Point(123, 70);
            this.numTypeTime.Maximum = new decimal(new int[] {
            3000,
            0,
            0,
            0});
            this.numTypeTime.Minimum = new decimal(new int[] {
            250,
            0,
            0,
            0});
            this.numTypeTime.Name = "numTypeTime";
            this.numTypeTime.Size = new System.Drawing.Size(100, 20);
            this.numTypeTime.TabIndex = 2;
            this.numTypeTime.Value = new decimal(new int[] {
            250,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Popup Browser Name";
            // 
            // txtPopupBrowserName
            // 
            this.txtPopupBrowserName.Location = new System.Drawing.Point(123, 37);
            this.txtPopupBrowserName.Name = "txtPopupBrowserName";
            this.txtPopupBrowserName.Size = new System.Drawing.Size(100, 20);
            this.txtPopupBrowserName.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Main Browser Name";
            // 
            // txtMainBrowserName
            // 
            this.txtMainBrowserName.Location = new System.Drawing.Point(123, 11);
            this.txtMainBrowserName.Name = "txtMainBrowserName";
            this.txtMainBrowserName.Size = new System.Drawing.Size(100, 20);
            this.txtMainBrowserName.TabIndex = 0;
            // 
            // pageCompiler
            // 
            this.pageCompiler.Controls.Add(this.btnVS05Path);
            this.pageCompiler.Controls.Add(this.txtVS05Path);
            this.pageCompiler.Controls.Add(this.rbVS05Lib);
            this.pageCompiler.Controls.Add(this.btnMBUnitPath);
            this.pageCompiler.Controls.Add(this.txtMBUnitPath);
            this.pageCompiler.Controls.Add(this.rbMBUnit);
            this.pageCompiler.Controls.Add(this.chkHideDOSWindow);
            this.pageCompiler.Controls.Add(this.label8);
            this.pageCompiler.Controls.Add(this.btnRemoveAssembly);
            this.pageCompiler.Controls.Add(this.btnAddAssembly);
            this.pageCompiler.Controls.Add(this.btnFindAssembly);
            this.pageCompiler.Controls.Add(this.txtAssembly);
            this.pageCompiler.Controls.Add(this.lbAssemblies);
            this.pageCompiler.Controls.Add(this.btnNUnitPath);
            this.pageCompiler.Controls.Add(this.txtNUnitPath);
            this.pageCompiler.Controls.Add(this.label4);
            this.pageCompiler.Controls.Add(this.btnCompilePath);
            this.pageCompiler.Controls.Add(this.rbNUnit);
            this.pageCompiler.Controls.Add(this.rbConsole);
            this.pageCompiler.Controls.Add(this.rbSnippet);
            this.pageCompiler.Controls.Add(this.label3);
            this.pageCompiler.Controls.Add(this.txtCompilePath);
            this.pageCompiler.Location = new System.Drawing.Point(4, 22);
            this.pageCompiler.Name = "pageCompiler";
            this.pageCompiler.Padding = new System.Windows.Forms.Padding(3);
            this.pageCompiler.Size = new System.Drawing.Size(553, 383);
            this.pageCompiler.TabIndex = 1;
            this.pageCompiler.Text = "Compiler";
            this.pageCompiler.UseVisualStyleBackColor = true;
            // 
            // rbVS05Lib
            // 
            this.rbVS05Lib.AutoSize = true;
            this.rbVS05Lib.Location = new System.Drawing.Point(85, 97);
            this.rbVS05Lib.Name = "rbVS05Lib";
            this.rbVS05Lib.Size = new System.Drawing.Size(121, 17);
            this.rbVS05Lib.TabIndex = 41;
            this.rbVS05Lib.Text = "VS2005 Test Library";
            this.rbVS05Lib.UseVisualStyleBackColor = true;
            // 
            // btnMBUnitPath
            // 
            this.btnMBUnitPath.ImageIndex = 4;
            this.btnMBUnitPath.ImageList = this.imageList1;
            this.btnMBUnitPath.Location = new System.Drawing.Point(505, 70);
            this.btnMBUnitPath.Name = "btnMBUnitPath";
            this.btnMBUnitPath.Size = new System.Drawing.Size(26, 23);
            this.btnMBUnitPath.TabIndex = 39;
            this.btnMBUnitPath.Text = "...";
            this.btnMBUnitPath.UseVisualStyleBackColor = true;
            this.btnMBUnitPath.Click += new System.EventHandler(this.btnMBUnitPath_Click);
            // 
            // txtMBUnitPath
            // 
            this.txtMBUnitPath.Location = new System.Drawing.Point(210, 73);
            this.txtMBUnitPath.Name = "txtMBUnitPath";
            this.txtMBUnitPath.ReadOnly = true;
            this.txtMBUnitPath.Size = new System.Drawing.Size(289, 20);
            this.txtMBUnitPath.TabIndex = 40;
            // 
            // rbMBUnit
            // 
            this.rbMBUnit.AutoSize = true;
            this.rbMBUnit.Location = new System.Drawing.Point(85, 74);
            this.rbMBUnit.Name = "rbMBUnit";
            this.rbMBUnit.Size = new System.Drawing.Size(94, 17);
            this.rbMBUnit.TabIndex = 38;
            this.rbMBUnit.Text = "MBUnit Library";
            this.rbMBUnit.UseVisualStyleBackColor = true;
            // 
            // chkHideDOSWindow
            // 
            this.chkHideDOSWindow.AutoSize = true;
            this.chkHideDOSWindow.Location = new System.Drawing.Point(210, 30);
            this.chkHideDOSWindow.Name = "chkHideDOSWindow";
            this.chkHideDOSWindow.Size = new System.Drawing.Size(116, 17);
            this.chkHideDOSWindow.TabIndex = 36;
            this.chkHideDOSWindow.Text = "Hide DOS Window";
            this.chkHideDOSWindow.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 159);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(118, 13);
            this.label8.TabIndex = 35;
            this.label8.Text = "Referenced Assemblies";
            // 
            // btnRemoveAssembly
            // 
            this.btnRemoveAssembly.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRemoveAssembly.ImageIndex = 3;
            this.btnRemoveAssembly.ImageList = this.imageList1;
            this.btnRemoveAssembly.Location = new System.Drawing.Point(456, 289);
            this.btnRemoveAssembly.Name = "btnRemoveAssembly";
            this.btnRemoveAssembly.Size = new System.Drawing.Size(75, 23);
            this.btnRemoveAssembly.TabIndex = 16;
            this.btnRemoveAssembly.Text = "Remove";
            this.btnRemoveAssembly.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRemoveAssembly.UseVisualStyleBackColor = true;
            this.btnRemoveAssembly.Click += new System.EventHandler(this.btnRemoveAssembly_Click);
            // 
            // btnAddAssembly
            // 
            this.btnAddAssembly.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddAssembly.ImageIndex = 2;
            this.btnAddAssembly.ImageList = this.imageList1;
            this.btnAddAssembly.Location = new System.Drawing.Point(375, 289);
            this.btnAddAssembly.Name = "btnAddAssembly";
            this.btnAddAssembly.Size = new System.Drawing.Size(75, 23);
            this.btnAddAssembly.TabIndex = 15;
            this.btnAddAssembly.Text = "Add";
            this.btnAddAssembly.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAddAssembly.UseVisualStyleBackColor = true;
            this.btnAddAssembly.Click += new System.EventHandler(this.btnAddAssembly_Click);
            // 
            // btnFindAssembly
            // 
            this.btnFindAssembly.ImageIndex = 4;
            this.btnFindAssembly.ImageList = this.imageList1;
            this.btnFindAssembly.Location = new System.Drawing.Point(333, 289);
            this.btnFindAssembly.Name = "btnFindAssembly";
            this.btnFindAssembly.Size = new System.Drawing.Size(26, 23);
            this.btnFindAssembly.TabIndex = 14;
            this.btnFindAssembly.Text = "...";
            this.btnFindAssembly.UseVisualStyleBackColor = true;
            this.btnFindAssembly.Click += new System.EventHandler(this.btnFindAssembly_Click);
            // 
            // txtAssembly
            // 
            this.txtAssembly.Location = new System.Drawing.Point(9, 292);
            this.txtAssembly.Name = "txtAssembly";
            this.txtAssembly.ReadOnly = true;
            this.txtAssembly.Size = new System.Drawing.Size(318, 20);
            this.txtAssembly.TabIndex = 31;
            // 
            // lbAssemblies
            // 
            this.lbAssemblies.FormattingEnabled = true;
            this.lbAssemblies.Location = new System.Drawing.Point(9, 175);
            this.lbAssemblies.Name = "lbAssemblies";
            this.lbAssemblies.Size = new System.Drawing.Size(522, 108);
            this.lbAssemblies.TabIndex = 13;
            // 
            // btnNUnitPath
            // 
            this.btnNUnitPath.ImageIndex = 4;
            this.btnNUnitPath.ImageList = this.imageList1;
            this.btnNUnitPath.Location = new System.Drawing.Point(505, 47);
            this.btnNUnitPath.Name = "btnNUnitPath";
            this.btnNUnitPath.Size = new System.Drawing.Size(26, 23);
            this.btnNUnitPath.TabIndex = 12;
            this.btnNUnitPath.Text = "...";
            this.btnNUnitPath.UseVisualStyleBackColor = true;
            this.btnNUnitPath.Click += new System.EventHandler(this.btnNUnitPath_Click);
            // 
            // txtNUnitPath
            // 
            this.txtNUnitPath.Location = new System.Drawing.Point(210, 50);
            this.txtNUnitPath.Name = "txtNUnitPath";
            this.txtNUnitPath.ReadOnly = true;
            this.txtNUnitPath.Size = new System.Drawing.Size(289, 20);
            this.txtNUnitPath.TabIndex = 28;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 27;
            this.label4.Text = "Script Type";
            // 
            // btnCompilePath
            // 
            this.btnCompilePath.ImageIndex = 4;
            this.btnCompilePath.ImageList = this.imageList1;
            this.btnCompilePath.Location = new System.Drawing.Point(505, 124);
            this.btnCompilePath.Name = "btnCompilePath";
            this.btnCompilePath.Size = new System.Drawing.Size(26, 23);
            this.btnCompilePath.TabIndex = 8;
            this.btnCompilePath.Text = "...";
            this.btnCompilePath.UseVisualStyleBackColor = true;
            this.btnCompilePath.Click += new System.EventHandler(this.btnCompilePath_Click);
            // 
            // rbNUnit
            // 
            this.rbNUnit.AutoSize = true;
            this.rbNUnit.Location = new System.Drawing.Point(85, 51);
            this.rbNUnit.Name = "rbNUnit";
            this.rbNUnit.Size = new System.Drawing.Size(86, 17);
            this.rbNUnit.TabIndex = 11;
            this.rbNUnit.Text = "NUnit Library";
            this.rbNUnit.UseVisualStyleBackColor = true;
            // 
            // rbConsole
            // 
            this.rbConsole.AutoSize = true;
            this.rbConsole.Location = new System.Drawing.Point(85, 29);
            this.rbConsole.Name = "rbConsole";
            this.rbConsole.Size = new System.Drawing.Size(63, 17);
            this.rbConsole.TabIndex = 10;
            this.rbConsole.Text = "Console";
            this.rbConsole.UseVisualStyleBackColor = true;
            // 
            // rbSnippet
            // 
            this.rbSnippet.AutoSize = true;
            this.rbSnippet.Checked = true;
            this.rbSnippet.Location = new System.Drawing.Point(85, 8);
            this.rbSnippet.Name = "rbSnippet";
            this.rbSnippet.Size = new System.Drawing.Size(61, 17);
            this.rbSnippet.TabIndex = 9;
            this.rbSnippet.TabStop = true;
            this.rbSnippet.Text = "Snippet";
            this.rbSnippet.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 22;
            this.label3.Text = "Compile Path";
            // 
            // txtCompilePath
            // 
            this.txtCompilePath.Location = new System.Drawing.Point(85, 127);
            this.txtCompilePath.Name = "txtCompilePath";
            this.txtCompilePath.ReadOnly = true;
            this.txtCompilePath.Size = new System.Drawing.Size(414, 20);
            this.txtCompilePath.TabIndex = 21;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnCancel);
            this.panel1.Controls.Add(this.btnDone);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 355);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(561, 54);
            this.panel1.TabIndex = 25;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancel.ImageIndex = 1;
            this.btnCancel.ImageList = this.imageList1;
            this.btnCancel.Location = new System.Drawing.Point(116, 16);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnDone
            // 
            this.btnDone.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnDone.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDone.ImageIndex = 0;
            this.btnDone.ImageList = this.imageList1;
            this.btnDone.Location = new System.Drawing.Point(9, 16);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(75, 23);
            this.btnDone.TabIndex = 6;
            this.btnDone.Text = "Done";
            this.btnDone.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDone.UseVisualStyleBackColor = true;
            // 
            // openAssemblyDialog
            // 
            this.openAssemblyDialog.DefaultExt = "dll";
            this.openAssemblyDialog.Filter = ".Net Assembly|*.dll";
            // 
            // openMBUnitDialog
            // 
            this.openMBUnitDialog.FileName = "MbUnit.Framework.dll";
            // 
            // btnVS05Path
            // 
            this.btnVS05Path.ImageIndex = 4;
            this.btnVS05Path.ImageList = this.imageList1;
            this.btnVS05Path.Location = new System.Drawing.Point(505, 93);
            this.btnVS05Path.Name = "btnVS05Path";
            this.btnVS05Path.Size = new System.Drawing.Size(26, 23);
            this.btnVS05Path.TabIndex = 42;
            this.btnVS05Path.Text = "...";
            this.btnVS05Path.UseVisualStyleBackColor = true;
            this.btnVS05Path.Click += new System.EventHandler(this.btnVS05Path_Click);
            // 
            // txtVS05Path
            // 
            this.txtVS05Path.Location = new System.Drawing.Point(210, 96);
            this.txtVS05Path.Name = "txtVS05Path";
            this.txtVS05Path.ReadOnly = true;
            this.txtVS05Path.Size = new System.Drawing.Size(289, 20);
            this.txtVS05Path.TabIndex = 43;
            // 
            // openVS05Dialog
            // 
            this.openVS05Dialog.FileName = "Microsoft.VisualStudio.QualityTools.UnitTestFramework.dll";
            // 
            // frmSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(561, 409);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tabControl1);
            this.Name = "frmSettings";
            this.Text = "Settings";
            this.tabControl1.ResumeLayout(false);
            this.pageGeneral.ResumeLayout(false);
            this.pageGeneral.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTypeTime)).EndInit();
            this.pageCompiler.ResumeLayout(false);
            this.pageCompiler.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.OpenFileDialog openNUnitDialog;
        private System.Windows.Forms.FolderBrowserDialog fbCompilePathDialog;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage pageGeneral;
        private System.Windows.Forms.CheckBox chkWarnUnsaved;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnCodeFont;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnDOMColor;
        private System.Windows.Forms.Panel pnlDOMColor;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown numTypeTime;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPopupBrowserName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtMainBrowserName;
        private System.Windows.Forms.TabPage pageCompiler;
        private System.Windows.Forms.Button btnNUnitPath;
        private System.Windows.Forms.TextBox txtNUnitPath;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnCompilePath;
        private System.Windows.Forms.RadioButton rbNUnit;
        private System.Windows.Forms.RadioButton rbConsole;
        private System.Windows.Forms.RadioButton rbSnippet;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCompilePath;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnDone;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnRemoveAssembly;
        private System.Windows.Forms.Button btnAddAssembly;
        private System.Windows.Forms.Button btnFindAssembly;
        private System.Windows.Forms.TextBox txtAssembly;
        private System.Windows.Forms.ListBox lbAssemblies;
        private System.Windows.Forms.OpenFileDialog openAssemblyDialog;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblSourceFont;
        private System.Windows.Forms.CheckBox chkHideDOSWindow;
        private System.Windows.Forms.Button btnMBUnitPath;
        private System.Windows.Forms.TextBox txtMBUnitPath;
        private System.Windows.Forms.RadioButton rbMBUnit;
        private System.Windows.Forms.OpenFileDialog openMBUnitDialog;
        private System.Windows.Forms.RadioButton rbVS05Lib;
        private System.Windows.Forms.Button btnVS05Path;
        private System.Windows.Forms.TextBox txtVS05Path;
        private System.Windows.Forms.OpenFileDialog openVS05Dialog;
    }
}