using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using WatiN.Core;
using System.Runtime.InteropServices;


namespace DemoApp
{
    [TestFixture]
    public class WatinScriptTest
    {
        [Test]
        public void CompileTest()
        {
            WatinScript script = new WatinScript();
            string Code = "IE ie = new IE();";
            script.ScriptFormatting = WatinScript.ScriptFormats.Console;
            script.CompileScript(Code, true);
        }
    }

    [TestFixture]
    public class RunningTests
    {
        frmMain main = new frmMain();
        public static string MainTestURL = @"C:\Program Files\WatiN\trunk\src\UnitTests\html\main.html";

        [SetUp]
        public void OpenWindow()
        {
            main.Show();
            main.wscript.Recording = true;
        }

        [TearDown]
        public void CloseWindow()
        {
            main.wscript.WarnWhenUnsaved = false;
            main.Close();
        }

        [Test]
        public void SurfToGoogle()
        {
            main.txtCode.Clear();
            main.NavToUrl("http://www.google.com");
            StringAssert.Contains("ie.GoTo(\"http://www.google.com\");", main.txtCode.Text);
        }

        [Test]
        public void TestPageClick()
        {
            main.NavToUrl(MainTestURL);
            main.txtCode.Clear();
            /*
            WatiN.Core.IE.Settings.EmbeddedIE = true;
            IE ie = WatiN.Core.IE.AttachToIE(WatiN.Core.Find.ByUrl(MainTestURL));
            RadioButton btn = ie.RadioButton(Find.ById("Radio1"));
            mshtml.IHTMLElement helem = btn.HTMLElement as mshtml.IHTMLElement;
            helem.scrollIntoView(false);
            uint x = (uint)helem.offsetLeft;
            uint y = (uint)helem.offsetTop;
            */

            StringAssert.Contains("ie.RadioButton(Find.ById(\"Radio1\")).Click();", main.txtCode.Text);
        }

        [Test]
        public void TestPageKeys()
        {
            main.NavToUrl(MainTestURL);
            main.txtCode.Clear();
            WatiN.Core.IE.Settings.EmbeddedIE = true;
            IE ie = WatiN.Core.IE.AttachToIE(WatiN.Core.Find.ByUrl(MainTestURL));
            ie.TextField(Find.ById("name")).TypeText("abc");
            StringAssert.Contains("ie.TextField(Find.ById(\"name\")).TypeText(\"abc\");", main.txtCode.Text);
        }
    }
}
